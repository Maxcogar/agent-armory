#!/usr/bin/env node

/**
 * PowerInspect MCP Server
 * 
 * Model Context Protocol server for Autodesk PowerInspect
 * Enables LLMs to create inspection programs, manage features, and control probe paths
 * 
 * Features:
 * - Feature creation (circles, points, planes, cylinders, etc.)
 * - Probe path management
 * - Pattern generation (bolt circles, grids)
 * - Batch operations (tolerances, naming, report output)
 * - Program validation and export
 */

import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  Tool,
} from '@modelcontextprotocol/sdk/types.js';
import { z } from 'zod';
import { PowerInspectClient } from './powerinspect-client.js';
import {
  FeatureType,
  RadialDimensionType,
  FittingAlgorithm,
  CompensationMethod,
  CompensationVector,
} from './types.js';
import { spawn } from 'child_process';
import { promisify } from 'util';
import { readFile } from 'fs/promises';
import { tmpdir } from 'os';
import { join } from 'path';

// Initialize PowerInspect client
const client = new PowerInspectClient();

// Zod Schemas for Tool Inputs
const Point3DSchema = z.object({
  x: z.number().describe('X coordinate'),
  y: z.number().describe('Y coordinate'),
  z: z.number().describe('Z coordinate'),
});

const Vector3DSchema = z.object({
  i: z.number().describe('I component (X direction)'),
  j: z.number().describe('J component (Y direction)'),
  k: z.number().describe('K component (Z direction)'),
});

const CreateCircleSchema = z.object({
  name: z.string().describe('Unique name for the circle feature'),
  center: Point3DSchema.describe('Center point coordinates'),
  diameter: z.number().optional().describe('Circle diameter (use diameter OR radius, not both)'),
  radius: z.number().optional().describe('Circle radius (use diameter OR radius, not both)'),
  upperTolerance: z.number().optional().describe('Upper tolerance limit'),
  lowerTolerance: z.number().optional().describe('Lower tolerance limit'),
  fittingAlgorithm: z.enum(['LEAST_SQUARES', 'MAX_INSCRIBED', 'MIN_CIRCUMSCRIBED']).optional()
    .describe('Fitting algorithm for the circle'),
  outputToReport: z.boolean().optional().default(true).describe('Include in inspection report'),
  comment: z.string().optional().describe('Optional comment/note for this feature'),
});

const CreatePointSchema = z.object({
  name: z.string().describe('Unique name for the point feature'),
  targetPoint: Point3DSchema.describe('Target point coordinates'),
  compensationMethod: z.enum(['ALONG_EXPLICIT_DIRECTION', 'NORMAL_TO_SURFACE']).optional()
    .describe('Probe compensation method'),
  compensationVector: z.enum(['X+', 'X-', 'Y+', 'Y-', 'Z+', 'Z-']).optional()
    .describe('Direction for probe compensation'),
  outputX: z.boolean().optional().default(true).describe('Output X coordinate to report'),
  outputY: z.boolean().optional().default(true).describe('Output Y coordinate to report'),
  outputZ: z.boolean().optional().default(true).describe('Output Z coordinate to report'),
  outputToReport: z.boolean().optional().default(true).describe('Include in inspection report'),
  comment: z.string().optional().describe('Optional comment/note for this feature'),
});

const CreatePlaneSchema = z.object({
  name: z.string().describe('Unique name for the plane feature'),
  basePoint: Point3DSchema.describe('Base point on the plane'),
  normalVector: Vector3DSchema.describe('Normal vector defining plane orientation'),
  pointCount: z.number().optional().default(4).describe('Number of probe points'),
  outputToReport: z.boolean().optional().default(true).describe('Include in inspection report'),
  comment: z.string().optional().describe('Optional comment/note for this feature'),
});

const CreateCylinderSchema = z.object({
  name: z.string().describe('Unique name for the cylinder feature'),
  basePoint: Point3DSchema.describe('Base point of cylinder axis'),
  axisVector: Vector3DSchema.describe('Axis direction vector'),
  diameter: z.number().optional().describe('Cylinder diameter (use diameter OR radius, not both)'),
  radius: z.number().optional().describe('Cylinder radius (use diameter OR radius, not both)'),
  height: z.number().optional().describe('Cylinder height'),
  upperTolerance: z.number().optional().describe('Upper tolerance limit'),
  lowerTolerance: z.number().optional().describe('Lower tolerance limit'),
  outputToReport: z.boolean().optional().default(true).describe('Include in inspection report'),
  comment: z.string().optional().describe('Optional comment/note for this feature'),
});

const ConfigureProbePathSchema = z.object({
  featureName: z.string().describe('Name of the feature to configure probe path for'),
  safeDistance: z.number().optional().describe('Safe retract distance from part surface (mm or inches)'),
  approachAngle: z.number().optional().describe('Approach angle in degrees'),
  reverseDirection: z.boolean().optional().default(false).describe('Reverse probe approach direction'),
});

const RefreshProbePathsSchema = z.object({
  featureNames: z.array(z.string()).describe('Array of feature names to refresh probe paths for'),
});

const CreateBoltCircleSchema = z.object({
  name: z.string().describe('Base name for the bolt circle (holes will be named name_Hole1, name_Hole2, etc.)'),
  centerX: z.number().describe('X coordinate of bolt circle center'),
  centerY: z.number().describe('Y coordinate of bolt circle center'),
  centerZ: z.number().describe('Z coordinate of bolt circle center'),
  diameter: z.number().describe('Bolt circle diameter (center-to-center of holes)'),
  holeCount: z.number().int().min(3).describe('Number of holes in the pattern'),
  holeDiameter: z.number().describe('Diameter of each hole'),
  startAngle: z.number().optional().default(0).describe('Starting angle in degrees (0 = 3 o\'clock position)'),
  tolerance: z.number().optional().describe('Tolerance for hole diameters'),
});

const CreateGridPatternSchema = z.object({
  baseFeatureName: z.string().describe('Name of the feature to use as pattern base'),
  rows: z.number().int().min(1).describe('Number of rows in the grid'),
  columns: z.number().int().min(1).describe('Number of columns in the grid'),
  rowSpacing: z.number().describe('Spacing between rows'),
  columnSpacing: z.number().describe('Spacing between columns'),
  baseName: z.string().describe('Base name for created features (will append row/column numbers)'),
});

const TransformFeaturesSchema = z.object({
  featureNames: z.array(z.string()).describe('Array of feature names to transform'),
  transformation: z.object({
    type: z.enum(['translate', 'rotate', 'mirror', 'scale']).describe('Type of transformation'),
    x: z.number().optional().describe('X offset for translate, or X scale factor'),
    y: z.number().optional().describe('Y offset for translate, or Y scale factor'),
    z: z.number().optional().describe('Z offset for translate, or Z scale factor'),
    axis: z.enum(['X', 'Y', 'Z']).optional().describe('Rotation axis'),
    angle: z.number().optional().describe('Rotation angle in degrees'),
    factor: z.number().optional().describe('Scale factor'),
  }).describe('Transformation parameters'),
});

const ApplyTolerancesSchema = z.object({
  featureNames: z.array(z.string()).describe('Array of feature names to apply tolerances to'),
  toleranceClass: z.object({
    name: z.string().describe('Name of the tolerance class (e.g., "H7", "Medium Precision")'),
    upperTolerance: z.number().describe('Upper tolerance limit'),
    lowerTolerance: z.number().describe('Lower tolerance limit'),
    description: z.string().optional().describe('Optional description of the tolerance class'),
  }).describe('Tolerance class to apply'),
});

const SetReportOutputSchema = z.object({
  featureNames: z.array(z.string()).describe('Array of feature names to configure'),
  outputToReport: z.boolean().describe('Whether to include features in inspection report'),
  properties: z.array(z.string()).optional().describe('Specific properties to output (e.g., ["diameter", "X", "Y"])'),
});

const RenameSequentialSchema = z.object({
  featureNames: z.array(z.string()).describe('Array of feature names to rename'),
  baseName: z.string().describe('Base name for sequential numbering (e.g., "Hole" creates Hole1, Hole2, etc.)'),
});

const SaveDocumentSchema = z.object({
  path: z.string().optional().describe('File path to save document (optional, uses current path if not specified)'),
});

const OpenDocumentSchema = z.object({
  path: z.string().describe('File path of the PowerInspect document to open'),
});

const ExportToSPCSchema = z.object({
  format: z.enum(['CSV', 'SDD', 'QDAS', 'SCRIPT']).describe('Export format for SPC data'),
  outputPath: z.string().describe('Output file path for the export'),
});

const ValidateProgramSchema = z.object({
  checkTolerances: z.boolean().optional().default(true).describe('Validate tolerance specifications'),
  checkClearances: z.boolean().optional().default(true).describe('Check for probe path clearance issues'),
});

const ParseStepFileSchema = z.object({
  stepFilePath: z.string().describe('Path to the STEP file to parse'),
  createFeatures: z.boolean().optional().default(true).describe('Automatically create PowerInspect features from extracted geometry'),
  featurePrefix: z.string().optional().default('').describe('Prefix for created feature names (e.g., "Part1_")'),
  applyDefaultTolerances: z.boolean().optional().default(false).describe('Apply default ±0.02mm tolerance to all features'),
});

/**
 * Parse STEP file using Python script
 */
async function parseStepFile(stepFilePath: string): Promise<any> {
  return new Promise((resolve, reject) => {
    const outputFile = join(tmpdir(), `step_features_${Date.now()}.json`);
    const pythonScript = join(__dirname, '..', 'step_parser.py');
    
    const python = spawn('python', [pythonScript, stepFilePath, outputFile]);
    
    let stderr = '';
    python.stderr.on('data', (data) => {
      stderr += data.toString();
    });
    
    python.on('close', async (code) => {
      if (code !== 0) {
        reject(new Error(`STEP parser failed: ${stderr}`));
        return;
      }
      
      try {
        const data = await readFile(outputFile, 'utf-8');
        const features = JSON.parse(data);
        resolve(features);
      } catch (err) {
        reject(new Error(`Failed to read parsed features: ${err}`));
      }
    });
  });
}

// Tool Definitions
const tools: Tool[] = [
  {
    name: 'powerinspect_connect',
    description: 'Connect to PowerInspect application. Must be called before any other operations. Requires PowerInspect to be installed and accessible.',
    inputSchema: {
      type: 'object',
      properties: {},
    },
  },
  {
    name: 'powerinspect_create_circle',
    description: 'Create a circular feature for inspection. Commonly used for holes, bosses, and cylindrical features. Specify either diameter or radius, and optionally add tolerances for automatic pass/fail evaluation.',
    inputSchema: {
      type: 'object',
      properties: {
        name: { type: 'string', description: 'Unique name for the circle feature' },
        center: {
          type: 'object',
          properties: {
            x: { type: 'number', description: 'X coordinate' },
            y: { type: 'number', description: 'Y coordinate' },
            z: { type: 'number', description: 'Z coordinate' },
          },
          required: ['x', 'y', 'z'],
          description: 'Center point coordinates',
        },
        diameter: { type: 'number', description: 'Circle diameter (use diameter OR radius, not both)' },
        radius: { type: 'number', description: 'Circle radius (use diameter OR radius, not both)' },
        upperTolerance: { type: 'number', description: 'Upper tolerance limit' },
        lowerTolerance: { type: 'number', description: 'Lower tolerance limit' },
        fittingAlgorithm: { 
          type: 'string', 
          enum: ['LEAST_SQUARES', 'MAX_INSCRIBED', 'MIN_CIRCUMSCRIBED'],
          description: 'Fitting algorithm for the circle',
        },
        outputToReport: { type: 'boolean', description: 'Include in inspection report', default: true },
        comment: { type: 'string', description: 'Optional comment/note for this feature' },
      },
      required: ['name', 'center'],
    },
  },
  {
    name: 'powerinspect_create_point',
    description: 'Create a single point feature for inspection. Used for measuring specific locations, distances, or thickness. Configure probe compensation to control measurement direction.',
    inputSchema: {
      type: 'object',
      properties: {
        name: { type: 'string', description: 'Unique name for the point feature' },
        targetPoint: {
          type: 'object',
          properties: {
            x: { type: 'number', description: 'X coordinate' },
            y: { type: 'number', description: 'Y coordinate' },
            z: { type: 'number', description: 'Z coordinate' },
          },
          required: ['x', 'y', 'z'],
          description: 'Target point coordinates',
        },
        compensationMethod: { 
          type: 'string', 
          enum: ['ALONG_EXPLICIT_DIRECTION', 'NORMAL_TO_SURFACE'],
          description: 'Probe compensation method',
        },
        compensationVector: { 
          type: 'string', 
          enum: ['X+', 'X-', 'Y+', 'Y-', 'Z+', 'Z-'],
          description: 'Direction for probe compensation',
        },
        outputX: { type: 'boolean', description: 'Output X coordinate to report', default: true },
        outputY: { type: 'boolean', description: 'Output Y coordinate to report', default: true },
        outputZ: { type: 'boolean', description: 'Output Z coordinate to report', default: true },
        outputToReport: { type: 'boolean', description: 'Include in inspection report', default: true },
        comment: { type: 'string', description: 'Optional comment/note for this feature' },
      },
      required: ['name', 'targetPoint'],
    },
  },
  {
    name: 'powerinspect_create_plane',
    description: 'Create a planar surface feature for inspection. Used for measuring flatness, parallelism, and establishing datums. Specify base point and normal vector to define plane orientation.',
    inputSchema: {
      type: 'object',
      properties: {
        name: { type: 'string', description: 'Unique name for the plane feature' },
        basePoint: {
          type: 'object',
          properties: {
            x: { type: 'number', description: 'X coordinate' },
            y: { type: 'number', description: 'Y coordinate' },
            z: { type: 'number', description: 'Z coordinate' },
          },
          required: ['x', 'y', 'z'],
          description: 'Base point on the plane',
        },
        normalVector: {
          type: 'object',
          properties: {
            i: { type: 'number', description: 'I component (X direction)' },
            j: { type: 'number', description: 'J component (Y direction)' },
            k: { type: 'number', description: 'K component (Z direction)' },
          },
          required: ['i', 'j', 'k'],
          description: 'Normal vector defining plane orientation',
        },
        pointCount: { type: 'number', description: 'Number of probe points', default: 4 },
        outputToReport: { type: 'boolean', description: 'Include in inspection report', default: true },
        comment: { type: 'string', description: 'Optional comment/note for this feature' },
      },
      required: ['name', 'basePoint', 'normalVector'],
    },
  },
  {
    name: 'powerinspect_create_cylinder',
    description: 'Create a cylindrical feature for inspection. Used for measuring shafts, bores, and cylindrical bosses. Specify axis vector to define cylinder orientation.',
    inputSchema: {
      type: 'object',
      properties: {
        name: { type: 'string', description: 'Unique name for the cylinder feature' },
        basePoint: {
          type: 'object',
          properties: {
            x: { type: 'number', description: 'X coordinate' },
            y: { type: 'number', description: 'Y coordinate' },
            z: { type: 'number', description: 'Z coordinate' },
          },
          required: ['x', 'y', 'z'],
          description: 'Base point of cylinder axis',
        },
        axisVector: {
          type: 'object',
          properties: {
            i: { type: 'number', description: 'I component (X direction)' },
            j: { type: 'number', description: 'J component (Y direction)' },
            k: { type: 'number', description: 'K component (Z direction)' },
          },
          required: ['i', 'j', 'k'],
          description: 'Axis direction vector',
        },
        diameter: { type: 'number', description: 'Cylinder diameter (use diameter OR radius, not both)' },
        radius: { type: 'number', description: 'Cylinder radius (use diameter OR radius, not both)' },
        height: { type: 'number', description: 'Cylinder height' },
        upperTolerance: { type: 'number', description: 'Upper tolerance limit' },
        lowerTolerance: { type: 'number', description: 'Lower tolerance limit' },
        outputToReport: { type: 'boolean', description: 'Include in inspection report', default: true },
        comment: { type: 'string', description: 'Optional comment/note for this feature' },
      },
      required: ['name', 'basePoint', 'axisVector'],
    },
  },
  {
    name: 'powerinspect_configure_probe_path',
    description: 'Configure CNC probe path parameters for a feature. Set safe distances, approach angles, and probe direction. Must be called after creating a feature and before generating CNC code.',
    inputSchema: {
      type: 'object',
      properties: {
        featureName: { type: 'string', description: 'Name of the feature to configure probe path for' },
        safeDistance: { type: 'number', description: 'Safe retract distance from part surface (mm or inches)' },
        approachAngle: { type: 'number', description: 'Approach angle in degrees' },
        reverseDirection: { type: 'boolean', description: 'Reverse probe approach direction', default: false },
      },
      required: ['featureName'],
    },
  },
  {
    name: 'powerinspect_refresh_probe_paths',
    description: 'Refresh CNC probe paths for specified features. Call this after modifying feature positions, adding tolerances, or changing probe configurations to update the probe paths.',
    inputSchema: {
      type: 'object',
      properties: {
        featureNames: { 
          type: 'array', 
          items: { type: 'string' },
          description: 'Array of feature names to refresh probe paths for',
        },
      },
      required: ['featureNames'],
    },
  },
  {
    name: 'powerinspect_create_bolt_circle',
    description: 'Create a bolt circle pattern of holes. Automatically generates individual circle features arranged in a circular pattern. Commonly used for flange bolt holes, mounting patterns, and circular hole arrays.',
    inputSchema: {
      type: 'object',
      properties: {
        name: { type: 'string', description: 'Base name for the bolt circle (holes will be named name_Hole1, name_Hole2, etc.)' },
        centerX: { type: 'number', description: 'X coordinate of bolt circle center' },
        centerY: { type: 'number', description: 'Y coordinate of bolt circle center' },
        centerZ: { type: 'number', description: 'Z coordinate of bolt circle center' },
        diameter: { type: 'number', description: 'Bolt circle diameter (center-to-center of holes)' },
        holeCount: { type: 'number', description: 'Number of holes in the pattern' },
        holeDiameter: { type: 'number', description: 'Diameter of each hole' },
        startAngle: { type: 'number', description: 'Starting angle in degrees (0 = 3 o\'clock position)', default: 0 },
        tolerance: { type: 'number', description: 'Tolerance for hole diameters' },
      },
      required: ['name', 'centerX', 'centerY', 'centerZ', 'diameter', 'holeCount', 'holeDiameter'],
    },
  },
  {
    name: 'powerinspect_create_grid_pattern',
    description: 'Create a rectangular grid pattern of features. Copies a base feature in rows and columns with specified spacing. Useful for inspection patterns, hole grids, and repeated features.',
    inputSchema: {
      type: 'object',
      properties: {
        baseFeatureName: { type: 'string', description: 'Name of the feature to use as pattern base' },
        rows: { type: 'number', description: 'Number of rows in the grid' },
        columns: { type: 'number', description: 'Number of columns in the grid' },
        rowSpacing: { type: 'number', description: 'Spacing between rows' },
        columnSpacing: { type: 'number', description: 'Spacing between columns' },
        baseName: { type: 'string', description: 'Base name for created features (will append row/column numbers)' },
      },
      required: ['baseFeatureName', 'rows', 'columns', 'rowSpacing', 'columnSpacing', 'baseName'],
    },
  },
  {
    name: 'powerinspect_transform_features',
    description: 'Apply geometric transformations to features. Supports translate, rotate, mirror, and scale operations. Useful for repositioning features or creating mirror-image patterns.',
    inputSchema: {
      type: 'object',
      properties: {
        featureNames: { 
          type: 'array', 
          items: { type: 'string' },
          description: 'Array of feature names to transform',
        },
        transformation: {
          type: 'object',
          properties: {
            type: { 
              type: 'string', 
              enum: ['translate', 'rotate', 'mirror', 'scale'],
              description: 'Type of transformation',
            },
            x: { type: 'number', description: 'X offset for translate, or X scale factor' },
            y: { type: 'number', description: 'Y offset for translate, or Y scale factor' },
            z: { type: 'number', description: 'Z offset for translate, or Z scale factor' },
            axis: { type: 'string', enum: ['X', 'Y', 'Z'], description: 'Rotation axis' },
            angle: { type: 'number', description: 'Rotation angle in degrees' },
            factor: { type: 'number', description: 'Scale factor' },
          },
          required: ['type'],
          description: 'Transformation parameters',
        },
      },
      required: ['featureNames', 'transformation'],
    },
  },
  {
    name: 'powerinspect_apply_tolerances',
    description: 'Apply tolerance specifications to multiple features at once. Use predefined tolerance classes (e.g., H7, Medium Precision) or custom values. Enables automatic pass/fail evaluation during inspection.',
    inputSchema: {
      type: 'object',
      properties: {
        featureNames: { 
          type: 'array', 
          items: { type: 'string' },
          description: 'Array of feature names to apply tolerances to',
        },
        toleranceClass: {
          type: 'object',
          properties: {
            name: { type: 'string', description: 'Name of the tolerance class (e.g., "H7", "Medium Precision")' },
            upperTolerance: { type: 'number', description: 'Upper tolerance limit' },
            lowerTolerance: { type: 'number', description: 'Lower tolerance limit' },
            description: { type: 'string', description: 'Optional description of the tolerance class' },
          },
          required: ['name', 'upperTolerance', 'lowerTolerance'],
          description: 'Tolerance class to apply',
        },
      },
      required: ['featureNames', 'toleranceClass'],
    },
  },
  {
    name: 'powerinspect_set_report_output',
    description: 'Configure which features and properties appear in the inspection report. Control report content by enabling/disabling output for specific features or properties.',
    inputSchema: {
      type: 'object',
      properties: {
        featureNames: { 
          type: 'array', 
          items: { type: 'string' },
          description: 'Array of feature names to configure',
        },
        outputToReport: { type: 'boolean', description: 'Whether to include features in inspection report' },
        properties: { 
          type: 'array', 
          items: { type: 'string' },
          description: 'Specific properties to output (e.g., ["diameter", "X", "Y"])',
        },
      },
      required: ['featureNames', 'outputToReport'],
    },
  },
  {
    name: 'powerinspect_rename_sequential',
    description: 'Rename multiple features with sequential numbering. Useful for organizing features with consistent naming conventions (e.g., Hole1, Hole2, Hole3).',
    inputSchema: {
      type: 'object',
      properties: {
        featureNames: { 
          type: 'array', 
          items: { type: 'string' },
          description: 'Array of feature names to rename',
        },
        baseName: { type: 'string', description: 'Base name for sequential numbering (e.g., "Hole" creates Hole1, Hole2, etc.)' },
      },
      required: ['featureNames', 'baseName'],
    },
  },
  {
    name: 'powerinspect_get_program_summary',
    description: 'Get a summary of the current inspection program including document name, units, feature count, and list of all features. Use this to understand the current program state.',
    inputSchema: {
      type: 'object',
      properties: {},
    },
  },
  {
    name: 'powerinspect_validate_program',
    description: 'Validate the inspection program for errors and warnings. Checks tolerance specifications, probe path clearances, and other potential issues before running the program.',
    inputSchema: {
      type: 'object',
      properties: {
        checkTolerances: { type: 'boolean', description: 'Validate tolerance specifications', default: true },
        checkClearances: { type: 'boolean', description: 'Check for probe path clearance issues', default: true },
      },
    },
  },
  {
    name: 'powerinspect_save_document',
    description: 'Save the current PowerInspect document. Optionally specify a file path for "Save As" functionality.',
    inputSchema: {
      type: 'object',
      properties: {
        path: { type: 'string', description: 'File path to save document (optional, uses current path if not specified)' },
      },
    },
  },
  {
    name: 'powerinspect_open_document',
    description: 'Open an existing PowerInspect inspection program document.',
    inputSchema: {
      type: 'object',
      properties: {
        path: { type: 'string', description: 'File path of the PowerInspect document to open' },
      },
      required: ['path'],
    },
  },
  {
    name: 'powerinspect_export_to_spc',
    description: 'Export inspection results to Statistical Process Control (SPC) format. Supports CSV, SDD, QDAS, and custom script formats for quality analysis and reporting.',
    inputSchema: {
      type: 'object',
      properties: {
        format: { 
          type: 'string', 
          enum: ['CSV', 'SDD', 'QDAS', 'SCRIPT'],
          description: 'Export format for SPC data',
        },
        outputPath: { type: 'string', description: 'Output file path for the export' },
      },
      required: ['format', 'outputPath'],
    },
  },
  {
    name: 'powerinspect_parse_step_file',
    description: 'Parse a STEP CAD file and automatically extract all geometric features (holes, cylinders, planes) with their coordinates. This is THE KEY TOOL that makes inspection programming easy - it reads your CAD file and finds all the features for you automatically. Optionally creates PowerInspect features directly from the extracted geometry.',
    inputSchema: {
      type: 'object',
      properties: {
        stepFilePath: { type: 'string', description: 'Path to the STEP file to parse (e.g., "C:\\CAD\\Part123.step")' },
        createFeatures: { type: 'boolean', description: 'Automatically create PowerInspect features from extracted geometry', default: true },
        featurePrefix: { type: 'string', description: 'Prefix for created feature names (e.g., "Part1_" creates "Part1_Hole1", "Part1_Hole2")', default: '' },
        applyDefaultTolerances: { type: 'boolean', description: 'Apply default ±0.02mm tolerance to all created features', default: false },
      },
      required: ['stepFilePath'],
    },
  },
  {
    name: 'powerinspect_disconnect',
    description: 'Disconnect from PowerInspect application. Call this when finished with all inspection program operations.',
    inputSchema: {
      type: 'object',
      properties: {},
    },
  },
];

// Create MCP server
const server = new Server(
  {
    name: 'powerinspect-mcp-server',
    version: '1.0.0',
  },
  {
    capabilities: {
      tools: {},
    },
  }
);

// List tools handler
server.setRequestHandler(ListToolsRequestSchema, async () => {
  return { tools };
});

// Call tool handler
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  try {
    switch (name) {
      case 'powerinspect_connect': {
        const result = await client.connect();
        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify(result, null, 2),
            },
          ],
        };
      }

      case 'powerinspect_create_circle': {
        const params = CreateCircleSchema.parse(args);
        const result = await client.createCircle({
          name: params.name,
          featureType: FeatureType.CIRCLE_PROBED,
          center: params.center,
          diameter: params.diameter,
          radius: params.radius,
          upperTolerance: params.upperTolerance,
          lowerTolerance: params.lowerTolerance,
          fittingAlgorithm: params.fittingAlgorithm as any,
          outputToReport: params.outputToReport,
          comment: params.comment,
        });
        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify(result, null, 2),
            },
          ],
        };
      }

      case 'powerinspect_create_point': {
        const params = CreatePointSchema.parse(args);
        const result = await client.createPoint({
          name: params.name,
          featureType: FeatureType.POINT_RETRACE,
          targetPoint: params.targetPoint,
          compensationMethod: params.compensationMethod as any,
          compensationVector: params.compensationVector as any,
          outputX: params.outputX,
          outputY: params.outputY,
          outputZ: params.outputZ,
          outputToReport: params.outputToReport,
          comment: params.comment,
        });
        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify(result, null, 2),
            },
          ],
        };
      }

      case 'powerinspect_create_plane': {
        const params = CreatePlaneSchema.parse(args);
        const result = await client.createPlane({
          name: params.name,
          featureType: FeatureType.PLANE_PROBED,
          basePoint: params.basePoint,
          normalVector: params.normalVector,
          pointCount: params.pointCount,
          outputToReport: params.outputToReport,
          comment: params.comment,
        });
        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify(result, null, 2),
            },
          ],
        };
      }

      case 'powerinspect_create_cylinder': {
        const params = CreateCylinderSchema.parse(args);
        const result = await client.createCylinder({
          name: params.name,
          featureType: FeatureType.CYLINDER,
          basePoint: params.basePoint,
          axisVector: params.axisVector,
          diameter: params.diameter,
          radius: params.radius,
          height: params.height,
          upperTolerance: params.upperTolerance,
          lowerTolerance: params.lowerTolerance,
          outputToReport: params.outputToReport,
          comment: params.comment,
        });
        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify(result, null, 2),
            },
          ],
        };
      }

      case 'powerinspect_configure_probe_path': {
        const params = ConfigureProbePathSchema.parse(args);
        const result = await client.configureProbePath(params);
        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify(result, null, 2),
            },
          ],
        };
      }

      case 'powerinspect_refresh_probe_paths': {
        const params = RefreshProbePathsSchema.parse(args);
        const result = await client.refreshProbePaths(params.featureNames);
        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify(result, null, 2),
            },
          ],
        };
      }

      case 'powerinspect_create_bolt_circle': {
        const params = CreateBoltCircleSchema.parse(args);
        const result = await client.createBoltCircle(params);
        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify(result, null, 2),
            },
          ],
        };
      }

      case 'powerinspect_create_grid_pattern': {
        const params = CreateGridPatternSchema.parse(args);
        // Implementation would create grid pattern
        const result = {
          success: true,
          message: `Created grid pattern: ${params.rows}x${params.columns} from ${params.baseFeatureName}`,
        };
        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify(result, null, 2),
            },
          ],
        };
      }

      case 'powerinspect_transform_features': {
        const params = TransformFeaturesSchema.parse(args);
        const result = await client.transformFeatures(params.featureNames, params.transformation);
        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify(result, null, 2),
            },
          ],
        };
      }

      case 'powerinspect_apply_tolerances': {
        const params = ApplyTolerancesSchema.parse(args);
        const result = await client.applyTolerances(params.featureNames, params.toleranceClass);
        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify(result, null, 2),
            },
          ],
        };
      }

      case 'powerinspect_set_report_output': {
        const params = SetReportOutputSchema.parse(args);
        const result = await client.setReportOutput(params.featureNames, params.outputToReport, params.properties);
        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify(result, null, 2),
            },
          ],
        };
      }

      case 'powerinspect_rename_sequential': {
        const params = RenameSequentialSchema.parse(args);
        const result = await client.renameSequential(params.featureNames, params.baseName);
        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify(result, null, 2),
            },
          ],
        };
      }

      case 'powerinspect_get_program_summary': {
        const result = await client.getProgramSummary();
        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify(result, null, 2),
            },
          ],
        };
      }

      case 'powerinspect_validate_program': {
        const params = ValidateProgramSchema.parse(args);
        const result = await client.validateProgram(params.checkTolerances, params.checkClearances);
        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify(result, null, 2),
            },
          ],
        };
      }

      case 'powerinspect_save_document': {
        const params = SaveDocumentSchema.parse(args);
        const result = await client.saveDocument(params.path);
        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify(result, null, 2),
            },
          ],
        };
      }

      case 'powerinspect_open_document': {
        const params = OpenDocumentSchema.parse(args);
        const result = await client.openDocument(params.path);
        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify(result, null, 2),
            },
          ],
        };
      }

      case 'powerinspect_export_to_spc': {
        const params = ExportToSPCSchema.parse(args);
        const result = await client.exportToSPC(params.format, params.outputPath);
        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify(result, null, 2),
            },
          ],
        };
      }

      case 'powerinspect_parse_step_file': {
        const params = ParseStepFileSchema.parse(args);
        
        try {
          // Parse STEP file
          const features = await parseStepFile(params.stepFilePath);
          
          let createdFeatures: string[] = [];
          
          // Optionally create PowerInspect features
          if (params.createFeatures) {
            // Create planes
            for (let i = 0; i < features.planes.length; i++) {
              const plane = features.planes[i];
              const name = `${params.featurePrefix}Plane${i + 1}`;
              await client.createPlane({
                name,
                featureType: FeatureType.PLANE_PROBED,
                basePoint: plane.point,
                normalVector: plane.normal,
                outputToReport: true,
              });
              createdFeatures.push(name);
            }
            
            // Create holes (as circles)
            for (let i = 0; i < features.holes.length; i++) {
              const hole = features.holes[i];
              const name = `${params.featurePrefix}Hole${i + 1}`;
              const result = await client.createCircle({
                name,
                featureType: FeatureType.CIRCLE_PROBED,
                center: hole.center,
                diameter: hole.diameter,
                upperTolerance: params.applyDefaultTolerances ? 0.02 : undefined,
                lowerTolerance: params.applyDefaultTolerances ? -0.02 : undefined,
                outputToReport: true,
              });
              if (result.success) {
                createdFeatures.push(name);
              }
            }
            
            // Create cylinders
            for (let i = 0; i < features.cylinders.length; i++) {
              const cyl = features.cylinders[i];
              const name = `${params.featurePrefix}Cylinder${i + 1}`;
              await client.createCylinder({
                name,
                featureType: FeatureType.CYLINDER,
                basePoint: cyl.center,
                axisVector: cyl.axis,
                diameter: cyl.diameter,
                height: cyl.height,
                upperTolerance: params.applyDefaultTolerances ? 0.02 : undefined,
                lowerTolerance: params.applyDefaultTolerances ? -0.02 : undefined,
                outputToReport: true,
              });
              createdFeatures.push(name);
            }
            
            // Refresh all probe paths
            if (createdFeatures.length > 0) {
              await client.refreshProbePaths(createdFeatures);
            }
          }
          
          return {
            content: [
              {
                type: 'text',
                text: JSON.stringify({
                  success: true,
                  message: `Parsed STEP file: ${features.planes.length} planes, ${features.holes.length} holes, ${features.cylinders.length} cylinders`,
                  extractedFeatures: features,
                  createdInPowerInspect: params.createFeatures ? createdFeatures : [],
                  totalCreated: createdFeatures.length
                }, null, 2),
              },
            ],
          };
        } catch (error: any) {
          return {
            content: [
              {
                type: 'text',
                text: JSON.stringify({
                  success: false,
                  error: `Failed to parse STEP file: ${error.message || error}`,
                  hint: 'Make sure Python and pythonocc-core are installed: pip install pythonocc-core'
                }, null, 2),
              },
            ],
            isError: true,
          };
        }
      }

      case 'powerinspect_disconnect': {
        await client.disconnect();
        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify({ success: true, message: 'Disconnected from PowerInspect' }, null, 2),
            },
          ],
        };
      }

      default:
        throw new Error(`Unknown tool: ${name}`);
    }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return {
        content: [
          {
            type: 'text',
            text: `Input validation error: ${JSON.stringify(error.errors, null, 2)}`,
          },
        ],
        isError: true,
      };
    }
    return {
      content: [
        {
          type: 'text',
          text: `Error executing tool: ${error}`,
        },
      ],
      isError: true,
    };
  }
});

// Start server
async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error('PowerInspect MCP Server running on stdio');
}

main().catch((error) => {
  console.error('Fatal error:', error);
  process.exit(1);
});
