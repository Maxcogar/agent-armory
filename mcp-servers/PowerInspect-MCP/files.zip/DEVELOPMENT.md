# PowerInspect MCP Server - Development Guide

This guide provides implementation details for connecting to the actual PowerInspect COM API and extending the MCP server functionality.

## Table of Contents

1. [COM API Implementation](#com-api-implementation)
2. [Windows COM Integration](#windows-com-integration)
3. [Type Definitions](#type-definitions)
4. [Adding New Tools](#adding-new-tools)
5. [Error Handling](#error-handling)
6. [Testing Strategies](#testing-strategies)
7. [Deployment](#deployment)

---

## COM API Implementation

### Current State

The current implementation includes:
- ✅ Complete type definitions for PowerInspect API
- ✅ Mock client for development and testing
- ✅ Full MCP server structure
- ✅ 20+ tools covering core functionality
- ⏸️ Actual COM API connection (requires Windows + node-win32ole)

### Implementing Real COM Connection

To connect to the actual PowerInspect COM API, you'll need to:

#### 1. Install Windows COM Library

```bash
npm install node-win32ole
# or
npm install winax
```

#### 2. Update PowerInspectClient Connection

Edit `src/powerinspect-client.ts`:

```typescript
// At the top of the file
import * as win32ole from 'node-win32ole';
// or
import { VariantType } from 'winax';

export class PowerInspectClient {
  private app: any = null;
  private connected: boolean = false;

  async connect(): Promise<APIResponse<void>> {
    try {
      // Create COM object
      this.app = new win32ole.win32ole.ActiveXObject('PowerINSPECT.Application');
      
      // Make application visible (optional)
      this.app.Visible = true;
      
      // Check version
      const majorVersion = this.app.MajorVersion;
      const minorVersion = this.app.MinorVersion;
      
      if (majorVersion < 17) {
        return {
          success: false,
          error: `PowerInspect version ${majorVersion}.${minorVersion} not supported. Requires 17.1.0 or later.`
        };
      }
      
      this.connected = true;
      return {
        success: true,
        message: `Connected to PowerInspect ${majorVersion}.${minorVersion}`
      };
    } catch (error) {
      return {
        success: false,
        error: `Failed to connect to PowerInspect: ${error}`
      };
    }
  }
  
  // ... rest of the class
}
```

#### 3. Implement Feature Creation

```typescript
async createCircle(config: CircleConfig): Promise<APIResponse<string>> {
  try {
    if (!this.connected) {
      return { success: false, error: 'Not connected to PowerInspect' };
    }

    // Get active document and group
    const doc = this.app.ActiveDocument;
    if (!doc) {
      return { success: false, error: 'No active document' };
    }
    
    const group = doc.ActiveGroup;
    if (!group) {
      return { success: false, error: 'No active group' };
    }

    // Add circle feature
    // PWI_EntityItemType.pwi_ent_Feat_ProbedCircle_ = specific numeric constant
    const PWI_PROBED_CIRCLE = 123; // Replace with actual constant from API docs
    const circle = group.SequenceItems.AddItem(PWI_PROBED_CIRCLE);
    
    // Set name
    circle.Name = config.name;
    
    // Set center position
    circle.PropertyCentre.NominalCoord.X = config.center.x;
    circle.PropertyCentre.NominalCoord.Y = config.center.y;
    circle.PropertyCentre.NominalCoord.Z = config.center.z;
    
    // Set diameter or radius
    if (config.diameter !== undefined) {
      circle.PropertyRadius.Nominal = config.diameter / 2;
      circle.RadialDimensionType = 0; // pwi_Diameter
    } else if (config.radius !== undefined) {
      circle.PropertyRadius.Nominal = config.radius;
      circle.RadialDimensionType = 1; // pwi_Radius
    }
    
    // Set tolerances
    if (config.upperTolerance !== undefined) {
      circle.PropertyRadius.UpperTolerance = config.upperTolerance;
    }
    if (config.lowerTolerance !== undefined) {
      circle.PropertyRadius.LowerTolerance = config.lowerTolerance;
    }
    
    // Set fitting algorithm
    if (config.fittingAlgorithm) {
      const algoMap = {
        'LEAST_SQUARES': 0,
        'MAX_INSCRIBED': 1,
        'MIN_CIRCUMSCRIBED': 2
      };
      circle.ParameterFittingAlgorithm = algoMap[config.fittingAlgorithm];
    }
    
    // Set output to report
    if (config.outputToReport !== undefined) {
      circle.OutputToReport = config.outputToReport;
    }
    
    // Set comment
    if (config.comment) {
      circle.Comment = config.comment;
    }
    
    // Refresh feature
    circle.Refresh();
    
    // Refresh CNC probe path
    try {
      circle.CNCProbePathParameters.RefreshCNCProbePath();
    } catch (probeError) {
      console.warn('Probe path refresh failed:', probeError);
    }
    
    return {
      success: true,
      data: config.name,
      message: `Created circle '${config.name}'`
    };
  } catch (error) {
    return {
      success: false,
      error: `Failed to create circle: ${error}`
    };
  }
}
```

---

## Windows COM Integration

### Environment Setup

1. **Windows Requirements:**
   - Windows 10/11 or Windows Server
   - PowerInspect 2017 (17.1.0) or later installed
   - Administrative privileges for COM registration

2. **Node.js Setup:**
   - Node.js 18+ with Windows build tools
   - Visual Studio Build Tools (for native modules)

3. **Install Build Tools:**
   ```bash
   npm install --global windows-build-tools
   ```

### COM Type Constants

PowerInspect uses numeric constants for feature types. You'll need to reference the API documentation or use COM introspection to find these values.

```typescript
// Example constants (verify with actual API docs)
const PWI_EntityItemType = {
  pwi_ent_Feat_ProbedCircle_: 123,
  pwi_ent_Feat_ProbedEllipse_: 124,
  pwi_ent_Plane_Probed_: 125,
  pwi_ent_Point_RetracePoint_: 126,
  pwi_ent_Feat_Cylinder_: 127,
  // ... add all types
};

const PWI_Units = {
  units_MILLIMETERS: 0,
  units_INCHES: 1
};

const PWI_RadialDimensionType = {
  pwi_Radius: 0,
  pwi_Diameter: 1
};
```

### Error Handling in COM

COM operations can throw various errors:

```typescript
try {
  const circle = group.SequenceItems.AddItem(PWI_PROBED_CIRCLE);
} catch (error) {
  // COM errors come in different forms
  if (error.message.includes('0x80070057')) {
    return { success: false, error: 'Invalid parameter' };
  } else if (error.message.includes('0x80004005')) {
    return { success: false, error: 'Unspecified error - check PowerInspect state' };
  } else {
    return { success: false, error: `COM error: ${error}` };
  }
}
```

---

## Type Definitions

### Extending Type Definitions

The type system in `types.ts` is already comprehensive, but you may need to add more based on specific API features.

Example of adding a new feature type:

```typescript
// In types.ts
export interface TorusConfig extends FeatureConfig {
  centerPoint: Point3D;
  axisVector: Vector3D;
  majorRadius: number;
  minorRadius: number;
  upperTolerance?: number;
  lowerTolerance?: number;
}

// In powerinspect-client.ts
async createTorus(config: TorusConfig): Promise<APIResponse<string>> {
  // Implementation
}

// In index.ts - add schema
const CreateTorusSchema = z.object({
  name: z.string(),
  centerPoint: Point3DSchema,
  axisVector: Vector3DSchema,
  majorRadius: z.number(),
  minorRadius: z.number(),
  upperTolerance: z.number().optional(),
  lowerTolerance: z.number().optional(),
});

// Add tool definition and handler
```

---

## Adding New Tools

### Step-by-Step Process

1. **Define Types** (in `types.ts`):
```typescript
export interface MyFeatureConfig extends FeatureConfig {
  // Add specific properties
  specificProperty: number;
}
```

2. **Add Client Method** (in `powerinspect-client.ts`):
```typescript
async createMyFeature(config: MyFeatureConfig): Promise<APIResponse<string>> {
  // Implementation
}
```

3. **Create Zod Schema** (in `index.ts`):
```typescript
const CreateMyFeatureSchema = z.object({
  name: z.string().describe('Feature name'),
  specificProperty: z.number().describe('Specific property'),
  // ... other properties
});
```

4. **Add Tool Definition** (in `index.ts`):
```typescript
{
  name: 'powerinspect_create_my_feature',
  description: 'Create my custom feature type...',
  inputSchema: {
    type: 'object',
    properties: {
      // Match Zod schema structure
    },
    required: ['name', 'specificProperty'],
  },
}
```

5. **Add Tool Handler** (in `index.ts`):
```typescript
case 'powerinspect_create_my_feature': {
  const params = CreateMyFeatureSchema.parse(args);
  const result = await client.createMyFeature(params);
  return {
    content: [
      {
        type: 'text',
        text: JSON.stringify(result, null, 2),
      },
    ],
  };
}
```

---

## Error Handling

### Strategy

1. **Three-Layer Error Handling:**
   - COM API errors (lowest level)
   - Client method errors (middle level)
   - MCP tool errors (highest level)

2. **Actionable Error Messages:**
```typescript
// Bad
return { success: false, error: 'Error occurred' };

// Good
return {
  success: false,
  error: 'Failed to create circle: Feature name "Hole1" already exists. Try a different name or delete the existing feature first.'
};
```

3. **Error Recovery:**
```typescript
async createCircle(config: CircleConfig): Promise<APIResponse<string>> {
  try {
    // Attempt creation
  } catch (error) {
    // Try to recover
    if (error.message.includes('duplicate name')) {
      // Suggest alternative names
      const suggestion = `${config.name}_${Date.now()}`;
      return {
        success: false,
        error: `Feature name "${config.name}" already exists. Try "${suggestion}" instead.`
      };
    }
    
    // If no recovery possible, return clear error
    return {
      success: false,
      error: `Failed to create circle: ${error.message}`
    };
  }
}
```

---

## Testing Strategies

### 1. Unit Tests

Test individual client methods without COM:

```typescript
// tests/client.test.ts
import { PowerInspectClient } from '../src/powerinspect-client';

describe('PowerInspectClient', () => {
  let client: PowerInspectClient;
  
  beforeEach(() => {
    client = new PowerInspectClient();
  });
  
  test('createCircle validates input', async () => {
    const result = await client.createCircle({
      name: '',  // Invalid
      center: { x: 0, y: 0, z: 0 },
      diameter: 10
    });
    expect(result.success).toBe(false);
  });
});
```

### 2. Integration Tests

Test with actual PowerInspect instance:

```typescript
// tests/integration.test.ts
describe('PowerInspect Integration', () => {
  let client: PowerInspectClient;
  
  beforeAll(async () => {
    client = new PowerInspectClient();
    await client.connect();
  });
  
  afterAll(async () => {
    await client.disconnect();
  });
  
  test('creates circle feature', async () => {
    const result = await client.createCircle({
      name: 'TestCircle',
      center: { x: 10, y: 10, z: 0 },
      diameter: 5
    });
    expect(result.success).toBe(true);
  });
});
```

### 3. MCP Inspector Testing

Use the MCP Inspector for manual testing:

```bash
npm run inspector
```

Then test tools interactively through the UI.

### 4. End-to-End Testing

Create test scripts that simulate real workflows:

```typescript
// tests/e2e/flange-inspection.test.ts
test('creates complete flange inspection program', async () => {
  await client.connect();
  
  // Create datum
  const datum = await client.createPlane({ /* ... */ });
  expect(datum.success).toBe(true);
  
  // Create bolt circle
  const boltCircle = await client.createBoltCircle({ /* ... */ });
  expect(boltCircle.success).toBe(true);
  
  // Validate
  const validation = await client.validateProgram(true, true);
  expect(validation.data?.valid).toBe(true);
});
```

---

## Deployment

### Development Deployment

For local development with PowerInspect:

1. Build the project:
   ```bash
   npm run build
   ```

2. Configure your MCP client:
   ```json
   {
     "mcpServers": {
       "powerinspect-dev": {
         "command": "node",
         "args": ["C:\\dev\\powerinspect-mcp\\dist\\index.js"],
         "env": {}
       }
     }
   }
   ```

3. Test with your LLM/MCP client

### Production Deployment

For production use:

1. **Package as Executable:**
   ```bash
   npm install -g pkg
   pkg . --targets node18-win-x64
   ```

2. **Install as Windows Service:**
   Use `node-windows` to run as a service:
   ```bash
   npm install -g node-windows
   ```

3. **Network Deployment:**
   For remote access, consider wrapping in an HTTP server:
   ```typescript
   // Use streamable HTTP transport instead of stdio
   import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamable-http.js';
   ```

### Docker Deployment (Windows Containers)

For containerized deployment:

```dockerfile
# Dockerfile (Windows containers)
FROM mcr.microsoft.com/windows/servercore:ltsc2022

# Install Node.js
RUN curl -o nodejs.msi https://nodejs.org/dist/v18.17.0/node-v18.17.0-x64.msi
RUN msiexec /i nodejs.msi /qn

# Copy application
COPY . /app
WORKDIR /app

# Install dependencies and build
RUN npm install
RUN npm run build

# Run
CMD ["node", "dist/index.js"]
```

---

## Performance Optimization

### 1. Batch Operations

Instead of creating features one-by-one, batch them:

```typescript
async createMultipleCircles(configs: CircleConfig[]): Promise<APIResponse<string[]>> {
  const results: string[] = [];
  const doc = this.app.ActiveDocument;
  
  // Start transaction (if supported)
  doc.BeginUndoGroup();
  
  try {
    for (const config of configs) {
      const circle = await this.createCircle(config);
      if (circle.success && circle.data) {
        results.push(circle.data);
      }
    }
    
    // Commit transaction
    doc.EndUndoGroup();
    
    return {
      success: true,
      data: results,
      message: `Created ${results.length} circles`
    };
  } catch (error) {
    doc.CancelUndoGroup();
    return { success: false, error: `Batch operation failed: ${error}` };
  }
}
```

### 2. Lazy Loading

Don't load full program summary unless needed:

```typescript
async getProgramSummary(includeFeatures: boolean = true): Promise<APIResponse<ProgramSummary>> {
  const doc = this.app.ActiveDocument;
  
  const summary: ProgramSummary = {
    documentName: doc.Name,
    units: doc.Units,
    featureCount: doc.SequenceItems.Count,
    features: [],
    saved: doc.Saved
  };
  
  // Only load full feature list if requested
  if (includeFeatures) {
    for (let i = 1; i <= doc.SequenceItems.Count; i++) {
      const item = doc.SequenceItems(i);
      summary.features.push({
        name: item.Name,
        type: item.TypeName,
        outputToReport: item.OutputToReport
      });
    }
  }
  
  return { success: true, data: summary };
}
```

---

## Advanced Features

### 1. CAD Import and Feature Recognition

Future enhancement for automatic feature detection:

```typescript
async analyzeCadFile(stepFilePath: string): Promise<APIResponse<FeatureSuggestion[]>> {
  // This would require external CAD parsing library
  // or AI-based feature recognition
  
  // Pseudo-code:
  // 1. Load STEP file
  // 2. Extract geometric features
  // 3. Classify features (holes, bosses, faces)
  // 4. Generate inspection feature suggestions
  
  return {
    success: true,
    data: [
      {
        type: 'circle',
        location: { x: 10, y: 10, z: 0 },
        diameter: 8.0,
        confidence: 0.95
      }
    ]
  };
}
```

### 2. AI-Assisted Tolerance Selection

```typescript
async suggestTolerances(featureType: string, material: string, process: string): Promise<APIResponse<ToleranceClass>> {
  // Use AI/ML model to suggest appropriate tolerances
  // based on feature type, material, and manufacturing process
  
  const suggestions = {
    'circle-aluminum-cnc': {
      upperTolerance: 0.025,
      lowerTolerance: -0.025
    },
    'circle-steel-cast': {
      upperTolerance: 0.100,
      lowerTolerance: -0.100
    }
  };
  
  const key = `${featureType}-${material}-${process}`;
  const tolerance = suggestions[key] || suggestions['circle-aluminum-cnc'];
  
  return {
    success: true,
    data: {
      name: `${process.toUpperCase()}_${material}`,
      ...tolerance,
      description: `Suggested tolerance for ${featureType} in ${material} via ${process}`
    }
  };
}
```

---

## Troubleshooting Common Issues

### Issue: COM Connection Fails

**Symptoms:** "Failed to connect to PowerInspect" error

**Solutions:**
1. Verify PowerInspect is installed
2. Check COM registration: `regsvr32 PowerINSPECT.dll`
3. Run with administrative privileges
4. Verify PowerInspect license is valid

### Issue: Feature Creation Fails

**Symptoms:** Features not appearing in PowerInspect

**Solutions:**
1. Check that document is open
2. Verify active group exists
3. Call `Refresh()` after feature creation
4. Check for duplicate feature names

### Issue: Probe Path Errors

**Symptoms:** "RefreshCNCProbePath failed"

**Solutions:**
1. Set safe distances appropriately
2. Check for feature position errors
3. Verify probe configuration in PowerInspect
4. Ensure feature has valid nominals

---

## Next Steps

1. Implement actual COM API connection
2. Test with real PowerInspect instance
3. Add advanced features (CAD import, AI suggestions)
4. Build integration with your existing ERP/CAM workflows
5. Create comprehensive test suite

For questions or contributions, see the main README.md file.
