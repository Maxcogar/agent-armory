#!/usr/bin/env python3
"""
STEP File Feature Extractor for PowerInspect
Extracts geometric features (holes, cylinders, planes) from STEP files

Requirements:
    pip install OCC pythonocc-core

Usage:
    python step_parser.py input.step output.json
"""

import sys
import json
import math
from OCC.Core.STEPControl import STEPControl_Reader
from OCC.Core.TopExp import TopExp_Explorer
from OCC.Core.TopAbs import TopAbs_FACE
from OCC.Core.BRepAdaptor import BRepAdaptor_Surface
from OCC.Core.GeomAbs import GeomAbs_Plane, GeomAbs_Cylinder
from OCC.Core.gp import gp_Pnt, gp_Dir


def parse_step_file(step_file_path):
    """Parse STEP file and extract geometric features"""
    
    # Read STEP file
    step_reader = STEPControl_Reader()
    status = step_reader.ReadFile(step_file_path)
    
    if status != 1:  # IFSelect_RetDone
        raise Exception(f"Failed to read STEP file: {step_file_path}")
    
    # Transfer shapes
    step_reader.TransferRoots()
    shape = step_reader.OneShape()
    
    # Extract features
    features = {
        'planes': [],
        'cylinders': [],
        'holes': []
    }
    
    # Explore faces
    explorer = TopExp_Explorer(shape, TopAbs_FACE)
    
    while explorer.More():
        face = explorer.Current()
        surface = BRepAdaptor_Surface(face)
        surface_type = surface.GetType()
        
        # Extract planes
        if surface_type == GeomAbs_Plane:
            plane_data = extract_plane(surface)
            if plane_data:
                features['planes'].append(plane_data)
        
        # Extract cylinders
        elif surface_type == GeomAbs_Cylinder:
            cylinder_data = extract_cylinder(surface, face)
            if cylinder_data:
                # Determine if it's a hole (internal) or boss (external)
                if cylinder_data['is_hole']:
                    features['holes'].append({
                        'type': 'circle',  # Holes represented as circles
                        'center': cylinder_data['center'],
                        'diameter': cylinder_data['diameter'],
                        'depth': cylinder_data['height'],
                        'axis': cylinder_data['axis']
                    })
                else:
                    features['cylinders'].append(cylinder_data)
        
        explorer.Next()
    
    return features


def extract_plane(surface):
    """Extract plane parameters"""
    try:
        plane = surface.Plane()
        location = plane.Location()
        normal = plane.Axis().Direction()
        
        return {
            'type': 'plane',
            'point': {
                'x': location.X(),
                'y': location.Y(),
                'z': location.Z()
            },
            'normal': {
                'i': normal.X(),
                'j': normal.Y(),
                'k': normal.Z()
            }
        }
    except:
        return None


def extract_cylinder(surface, face):
    """Extract cylinder parameters"""
    try:
        cylinder = surface.Cylinder()
        location = cylinder.Location()
        axis = cylinder.Axis().Direction()
        radius = cylinder.Radius()
        
        # Determine if hole or boss by checking surface orientation
        # This is a heuristic - may need refinement
        from OCC.Core.BRep import BRep_Tool
        from OCC.Core.TopExp import topexp
        
        # Get first edge to estimate cylinder height
        from OCC.Core.BRepTools import breptools
        height = estimate_cylinder_height(face)
        
        # Simple heuristic: smaller radius = likely a hole
        is_hole = radius < 50  # Adjust threshold as needed
        
        return {
            'type': 'cylinder',
            'center': {
                'x': location.X(),
                'y': location.Y(),
                'z': location.Z()
            },
            'axis': {
                'i': axis.X(),
                'j': axis.Y(),
                'k': axis.Z()
            },
            'radius': radius,
            'diameter': radius * 2,
            'height': height,
            'is_hole': is_hole
        }
    except Exception as e:
        print(f"Error extracting cylinder: {e}", file=sys.stderr)
        return None


def estimate_cylinder_height(face):
    """Estimate cylinder height from face bounds"""
    try:
        from OCC.Core.Bnd import Bnd_Box
        from OCC.Core.BRepBndLib import brepbndlib
        
        bbox = Bnd_Box()
        brepbndlib.Add(face, bbox)
        
        xmin, ymin, zmin, xmax, ymax, zmax = bbox.Get()
        
        # Return maximum dimension as height estimate
        height = max(xmax - xmin, ymax - ymin, zmax - zmin)
        return height
    except:
        return 10.0  # Default height


def main():
    if len(sys.argv) != 3:
        print("Usage: python step_parser.py input.step output.json")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    
    try:
        print(f"Parsing STEP file: {input_file}", file=sys.stderr)
        features = parse_step_file(input_file)
        
        # Write to JSON
        with open(output_file, 'w') as f:
            json.dump(features, f, indent=2)
        
        print(f"Extracted features:", file=sys.stderr)
        print(f"  Planes: {len(features['planes'])}", file=sys.stderr)
        print(f"  Cylinders: {len(features['cylinders'])}", file=sys.stderr)
        print(f"  Holes: {len(features['holes'])}", file=sys.stderr)
        print(f"Output written to: {output_file}", file=sys.stderr)
        
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
