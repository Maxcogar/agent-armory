#!/usr/bin/env node

/**
 * PowerInspect Connection Test
 * 
 * Simple test script to verify PowerInspect COM connection works
 * 
 * Usage:
 *   node test-connection.js
 * 
 * Make sure PowerInspect is running with a document open before running this.
 */

console.log('PowerInspect Connection Test\n');

async function testConnection() {
  let winax;
  
  try {
    // Try to load winax
    console.log('1. Loading winax module...');
    winax = require('winax');
    console.log('   ✓ winax loaded successfully');
  } catch (e) {
    console.error('   ✗ Failed to load winax:', e.message);
    console.error('\n   Install with: npm install winax');
    process.exit(1);
  }

  let app;
  try {
    // Try to create PowerInspect COM object
    console.log('\n2. Connecting to PowerInspect...');
    app = new winax.Object('PowerINSPECT.Application', { activate: true, type: true });
    console.log('   ✓ Connected to PowerInspect COM object');
  } catch (e) {
    console.error('   ✗ Failed to connect to PowerInspect:', e.message);
    console.error('\n   Make sure:');
    console.error('   - PowerInspect is installed');
    console.error('   - PowerInspect is licensed');
    console.error('   - You have a document open in PowerInspect');
    console.error('   - You are running as Administrator (if needed)');
    process.exit(1);
  }

  try {
    // Get version
    console.log('\n3. Checking PowerInspect version...');
    const majorVersion = app.MajorVersion;
    const minorVersion = app.MinorVersion;
    console.log(`   ✓ PowerInspect version: ${majorVersion}.${minorVersion}`);
    
    if (majorVersion < 17) {
      console.warn(`   ⚠ Warning: Version ${majorVersion}.${minorVersion} may not be fully supported`);
      console.warn('   Recommended: PowerInspect 2017 (17.1.0) or later');
    }
  } catch (e) {
    console.error('   ✗ Failed to get version:', e.message);
  }

  try {
    // Get active document
    console.log('\n4. Checking active document...');
    const doc = app.ActiveDocument;
    if (!doc) {
      console.error('   ✗ No active document');
      console.error('\n   Please open or create a document in PowerInspect');
      process.exit(1);
    }
    console.log(`   ✓ Active document: ${doc.Name || 'Untitled'}`);
    console.log(`   ✓ Units: ${doc.Units === 0 ? 'Millimeters' : 'Inches'}`);
    console.log(`   ✓ Saved: ${doc.Saved ? 'Yes' : 'No (unsaved changes)'}`);
  } catch (e) {
    console.error('   ✗ Failed to get document:', e.message);
    console.error('\n   Make sure you have a document open in PowerInspect');
    process.exit(1);
  }

  try {
    // Get active group
    console.log('\n5. Checking active group...');
    const doc = app.ActiveDocument;
    const group = doc.ActiveGroup;
    if (!group) {
      console.error('   ✗ No active group');
      process.exit(1);
    }
    console.log(`   ✓ Active group: ${group.Name || 'Default Group'}`);
    console.log(`   ✓ Feature count: ${group.SequenceItems.Count}`);
  } catch (e) {
    console.error('   ✗ Failed to get group:', e.message);
  }

  try {
    // Optional: Test creating a simple point feature
    console.log('\n6. Testing feature creation...');
    const doc = app.ActiveDocument;
    const group = doc.ActiveGroup;
    
    // Create a test point
    const PWI_POINT_RETRACE = 15;
    const testPoint = group.SequenceItems.AddItem(PWI_POINT_RETRACE);
    testPoint.Name = 'MCP_Test_Point';
    testPoint.PropertyTargetPoint.NominalCoord.X = 0;
    testPoint.PropertyTargetPoint.NominalCoord.Y = 0;
    testPoint.PropertyTargetPoint.NominalCoord.Z = 0;
    testPoint.Refresh();
    
    console.log('   ✓ Successfully created test point "MCP_Test_Point"');
    console.log('   ✓ Check PowerInspect to verify the point appears');
    
    // Ask if they want to delete it
    console.log('\n   Note: Test point created in your program.');
    console.log('   You can delete it manually if desired.');
  } catch (e) {
    console.warn('   ⚠ Feature creation test failed:', e.message);
    console.warn('   This may be due to document permissions or state');
  }

  console.log('\n✓ All tests passed!');
  console.log('\nYour PowerInspect MCP server is ready to use.');
  console.log('\nNext steps:');
  console.log('1. Build the server: npm run build');
  console.log('2. Test with MCP Inspector: npm run inspector');
  console.log('3. Configure in Claude Desktop (see INSTALL.md)');
}

testConnection().catch(error => {
  console.error('\n✗ Test failed with error:', error);
  process.exit(1);
});
