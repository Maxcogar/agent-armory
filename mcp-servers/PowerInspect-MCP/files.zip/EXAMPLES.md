# PowerInspect MCP Server - Usage Examples

This document provides comprehensive examples for using the PowerInspect MCP server in various inspection scenarios.

## Table of Contents

1. [Basic Setup](#basic-setup)
2. [Simple Part Inspection](#simple-part-inspection)
3. [Flange with Bolt Circle](#flange-with-bolt-circle)
4. [Plate with Grid Pattern](#plate-with-grid-pattern)
5. [Shaft Inspection](#shaft-inspection)
6. [Complex HVAC Assembly](#complex-hvac-assembly)
7. [Mirror Patterns](#mirror-patterns)
8. [Batch Tolerance Application](#batch-tolerance-application)
9. [ERP Integration Workflow](#erp-integration-workflow)
10. [Advanced Transformations](#advanced-transformations)

---

## Basic Setup

Every session starts with connecting to PowerInspect:

```typescript
// Always start with connection
powerinspect_connect()
```

---

## Simple Part Inspection

Inspect a simple plate with 4 mounting holes.

```typescript
// 1. Connect
powerinspect_connect()

// 2. Establish datum plane (top surface)
powerinspect_create_plane({
  name: "DatumA",
  basePoint: { x: 0, y: 0, z: 0 },
  normalVector: { i: 0, j: 0, k: 1 },
  pointCount: 4,
  outputToReport: true,
  comment: "Top surface datum"
})

// 3. Create four corner holes
powerinspect_create_circle({
  name: "Hole_TopLeft",
  center: { x: 10, y: 10, z: 0 },
  diameter: 8.0,
  upperTolerance: 0.02,
  lowerTolerance: -0.02,
  fittingAlgorithm: "LEAST_SQUARES",
  outputToReport: true
})

powerinspect_create_circle({
  name: "Hole_TopRight",
  center: { x: 90, y: 10, z: 0 },
  diameter: 8.0,
  upperTolerance: 0.02,
  lowerTolerance: -0.02,
  outputToReport: true
})

powerinspect_create_circle({
  name: "Hole_BottomLeft",
  center: { x: 10, y: 90, z: 0 },
  diameter: 8.0,
  upperTolerance: 0.02,
  lowerTolerance: -0.02,
  outputToReport: true
})

powerinspect_create_circle({
  name: "Hole_BottomRight",
  center: { x: 90, y: 90, z: 0 },
  diameter: 8.0,
  upperTolerance: 0.02,
  lowerTolerance: -0.02,
  outputToReport: true
})

// 4. Configure probe paths
powerinspect_configure_probe_path({
  featureName: "DatumA",
  safeDistance: 5.0,
  approachAngle: 0.0
})

// Batch configure holes
const holes = ["Hole_TopLeft", "Hole_TopRight", "Hole_BottomLeft", "Hole_BottomRight"]
for (const hole of holes) {
  powerinspect_configure_probe_path({
    featureName: hole,
    safeDistance: 3.0,
    approachAngle: 45.0
  })
}

// 5. Validate and save
powerinspect_validate_program({
  checkTolerances: true,
  checkClearances: true
})

powerinspect_save_document({
  path: "C:\\Inspections\\SimplePlate.pwi"
})
```

---

## Flange with Bolt Circle

Inspect a flange with 8 bolt holes in a circular pattern.

```typescript
// 1. Connect
powerinspect_connect()

// 2. Create datum surfaces
powerinspect_create_plane({
  name: "FlangeTop",
  basePoint: { x: 0, y: 0, z: 0 },
  normalVector: { i: 0, j: 0, k: 1 },
  pointCount: 5,
  outputToReport: true,
  comment: "Flange top surface"
})

// 3. Create center bore
powerinspect_create_circle({
  name: "CenterBore",
  center: { x: 100, y: 100, z: 0 },
  diameter: 50.0,
  upperTolerance: 0.05,
  lowerTolerance: -0.05,
  fittingAlgorithm: "LEAST_SQUARES",
  outputToReport: true,
  comment: "Main center bore"
})

// 4. Create bolt circle pattern (8 holes)
powerinspect_create_bolt_circle({
  name: "BoltHoles",
  centerX: 100.0,
  centerY: 100.0,
  centerZ: 0.0,
  diameter: 150.0,
  holeCount: 8,
  holeDiameter: 12.0,
  startAngle: 0.0,
  tolerance: 0.02
})

// 5. Apply H7 tolerances to bolt holes
powerinspect_apply_tolerances({
  featureNames: [
    "BoltHoles_Hole1", "BoltHoles_Hole2", "BoltHoles_Hole3", "BoltHoles_Hole4",
    "BoltHoles_Hole5", "BoltHoles_Hole6", "BoltHoles_Hole7", "BoltHoles_Hole8"
  ],
  toleranceClass: {
    name: "H7",
    upperTolerance: 0.018,
    lowerTolerance: 0.000,
    description: "ISO H7 tolerance for bolt holes"
  }
})

// 6. Configure probe paths
powerinspect_refresh_probe_paths({
  featureNames: [
    "FlangeTop", "CenterBore",
    "BoltHoles_Hole1", "BoltHoles_Hole2", "BoltHoles_Hole3", "BoltHoles_Hole4",
    "BoltHoles_Hole5", "BoltHoles_Hole6", "BoltHoles_Hole7", "BoltHoles_Hole8"
  ]
})

// 7. Save
powerinspect_save_document({
  path: "C:\\Inspections\\Flange_8Bolt.pwi"
})
```

---

## Plate with Grid Pattern

Inspect a plate with a grid of threaded holes.

```typescript
// 1. Connect
powerinspect_connect()

// 2. Create datum plane
powerinspect_create_plane({
  name: "DatumA",
  basePoint: { x: 0, y: 0, z: 0 },
  normalVector: { i: 0, j: 0, k: 1 },
  pointCount: 4,
  outputToReport: true
})

// 3. Create first hole as pattern base
powerinspect_create_circle({
  name: "GridHole_Base",
  center: { x: 20, y: 20, z: 0 },
  diameter: 6.0,
  upperTolerance: 0.015,
  lowerTolerance: -0.015,
  outputToReport: true
})

// 4. Create grid pattern (5 rows x 4 columns)
powerinspect_create_grid_pattern({
  baseFeatureName: "GridHole_Base",
  rows: 5,
  columns: 4,
  rowSpacing: 25.0,
  columnSpacing: 30.0,
  baseName: "GridHole"
})

// 5. Apply medium precision tolerances to all grid holes
const gridHoles = []
for (let r = 1; r <= 5; r++) {
  for (let c = 1; c <= 4; c++) {
    gridHoles.push(`GridHole_R${r}C${c}`)
  }
}

powerinspect_apply_tolerances({
  featureNames: gridHoles,
  toleranceClass: {
    name: "MediumPrecision",
    upperTolerance: 0.015,
    lowerTolerance: -0.015,
    description: "Medium precision for threaded holes"
  }
})

// 6. Refresh probe paths
powerinspect_refresh_probe_paths({
  featureNames: gridHoles
})

// 7. Save
powerinspect_save_document({
  path: "C:\\Inspections\\GridPlate.pwi"
})
```

---

## Shaft Inspection

Inspect a cylindrical shaft with multiple diameters.

```typescript
// 1. Connect
powerinspect_connect()

// 2. Create datum plane (shaft end face)
powerinspect_create_plane({
  name: "EndFace",
  basePoint: { x: 0, y: 0, z: 0 },
  normalVector: { i: 0, j: 0, k: 1 },
  pointCount: 4,
  outputToReport: true,
  comment: "Shaft end face datum"
})

// 3. Create primary cylinder (main shaft body)
powerinspect_create_cylinder({
  name: "MainShaft",
  basePoint: { x: 0, y: 0, z: 5 },
  axisVector: { i: 0, j: 0, k: 1 },
  diameter: 50.0,
  height: 100.0,
  upperTolerance: 0.025,
  lowerTolerance: -0.025,
  outputToReport: true,
  comment: "Main shaft diameter"
})

// 4. Create stepped diameter
powerinspect_create_cylinder({
  name: "ReducedSection",
  basePoint: { x: 0, y: 0, z: 105 },
  axisVector: { i: 0, j: 0, k: 1 },
  diameter: 40.0,
  height: 50.0,
  upperTolerance: 0.020,
  lowerTolerance: -0.020,
  outputToReport: true,
  comment: "Reduced diameter section"
})

// 5. Create bearing journal
powerinspect_create_cylinder({
  name: "BearingJournal",
  basePoint: { x: 0, y: 0, z: 155 },
  axisVector: { i: 0, j: 0, k: 1 },
  diameter: 35.0,
  height: 30.0,
  upperTolerance: 0.010,
  lowerTolerance: -0.010,
  outputToReport: true,
  comment: "Bearing mounting surface - tight tolerance"
})

// 6. Create measurement points at key locations
powerinspect_create_point({
  name: "ShoulderHeight",
  targetPoint: { x: 0, y: 0, z: 105 },
  compensationVector: "Z+",
  outputToReport: true,
  comment: "Shoulder height measurement"
})

// 7. Configure probe paths
powerinspect_configure_probe_path({
  featureName: "MainShaft",
  safeDistance: 10.0,
  approachAngle: 90.0
})

powerinspect_configure_probe_path({
  featureName: "BearingJournal",
  safeDistance: 5.0,
  approachAngle: 90.0
})

// 8. Refresh all probe paths
powerinspect_refresh_probe_paths({
  featureNames: ["EndFace", "MainShaft", "ReducedSection", "BearingJournal", "ShoulderHeight"]
})

// 9. Validate and save
powerinspect_validate_program({
  checkTolerances: true,
  checkClearances: true
})

powerinspect_save_document({
  path: "C:\\Inspections\\Shaft_MultiDiameter.pwi"
})
```

---

## Complex HVAC Assembly

Inspect an HVAC assembly with multiple connection points (based on Max's solar project work).

```typescript
// 1. Connect
powerinspect_connect()

// 2. Create primary datum surfaces
powerinspect_create_plane({
  name: "MountingBase",
  basePoint: { x: 0, y: 0, z: 0 },
  normalVector: { i: 0, j: 0, k: 1 },
  pointCount: 6,
  outputToReport: true,
  comment: "Base mounting surface"
})

// 3. Create bolt circle for main mounting
powerinspect_create_bolt_circle({
  name: "BaseMounting",
  centerX: 150.0,
  centerY: 150.0,
  centerZ: 0.0,
  diameter: 200.0,
  holeCount: 6,
  holeDiameter: 10.0,
  startAngle: 0.0,
  tolerance: 0.025
})

// 4. Create inlet/outlet connection holes
powerinspect_create_circle({
  name: "InletPort",
  center: { x: 50, y: 150, z: 50 },
  diameter: 100.0,
  upperTolerance: 0.5,
  lowerTolerance: -0.5,
  outputToReport: true,
  comment: "Main inlet port"
})

powerinspect_create_circle({
  name: "OutletPort",
  center: { x: 250, y: 150, z: 50 },
  diameter: 100.0,
  upperTolerance: 0.5,
  lowerTolerance: -0.5,
  outputToReport: true,
  comment: "Main outlet port"
})

// 5. Create bolt circles for port flanges
powerinspect_create_bolt_circle({
  name: "InletFlange",
  centerX: 50.0,
  centerY: 150.0,
  centerZ: 50.0,
  diameter: 150.0,
  holeCount: 8,
  holeDiameter: 12.0,
  startAngle: 22.5,
  tolerance: 0.02
})

powerinspect_create_bolt_circle({
  name: "OutletFlange",
  centerX: 250.0,
  centerY: 150.0,
  centerZ: 50.0,
  diameter: 150.0,
  holeCount: 8,
  holeDiameter: 12.0,
  startAngle: 22.5,
  tolerance: 0.02
})

// 6. Create measurement points for critical dimensions
powerinspect_create_point({
  name: "InletHeight",
  targetPoint: { x: 50, y: 150, z: 50 },
  compensationVector: "Z+",
  outputToReport: true,
  comment: "Inlet centerline height"
})

powerinspect_create_point({
  name: "OutletHeight",
  targetPoint: { x: 250, y: 150, z: 50 },
  compensationVector: "Z+",
  outputToReport: true,
  comment: "Outlet centerline height"
})

// 7. Apply appropriate tolerances
powerinspect_apply_tolerances({
  featureNames: [
    "BaseMounting_Hole1", "BaseMounting_Hole2", "BaseMounting_Hole3",
    "BaseMounting_Hole4", "BaseMounting_Hole5", "BaseMounting_Hole6"
  ],
  toleranceClass: {
    name: "CoarseFit",
    upperTolerance: 0.025,
    lowerTolerance: -0.025,
    description: "Coarse fit for structural mounting"
  }
})

// 8. Configure all probe paths
const allFeatures = [
  "MountingBase", "InletPort", "OutletPort",
  "BaseMounting_Hole1", "BaseMounting_Hole2", "BaseMounting_Hole3",
  "BaseMounting_Hole4", "BaseMounting_Hole5", "BaseMounting_Hole6",
  "InletFlange_Hole1", "InletFlange_Hole2", /* ... all inlet flange holes */
  "OutletFlange_Hole1", "OutletFlange_Hole2", /* ... all outlet flange holes */
  "InletHeight", "OutletHeight"
]

powerinspect_refresh_probe_paths({
  featureNames: allFeatures
})

// 9. Save
powerinspect_save_document({
  path: "C:\\Inspections\\HVAC_Assembly_Solar.pwi"
})

// 10. Export to QDAS for SPC analysis
powerinspect_export_to_spc({
  format: "QDAS",
  outputPath: "C:\\Exports\\HVAC_Assembly_Solar.q2d"
})
```

---

## Mirror Patterns

Create mirrored features for symmetric parts.

```typescript
// 1. Connect
powerinspect_connect()

// 2. Create features on one side
powerinspect_create_circle({
  name: "Hole_Left_1",
  center: { x: -30, y: 20, z: 0 },
  diameter: 8.0,
  upperTolerance: 0.02,
  lowerTolerance: -0.02,
  outputToReport: true
})

powerinspect_create_circle({
  name: "Hole_Left_2",
  center: { x: -30, y: 40, z: 0 },
  diameter: 8.0,
  upperTolerance: 0.02,
  lowerTolerance: -0.02,
  outputToReport: true
})

// 3. Mirror across YZ plane (X=0)
powerinspect_transform_features({
  featureNames: ["Hole_Left_1", "Hole_Left_2"],
  transformation: {
    type: "mirror",
    axis: "X"
  }
})

// This creates mirrored features at (30, 20, 0) and (30, 40, 0)

// 4. Rename mirrored features
powerinspect_rename_sequential({
  featureNames: ["Hole_Left_1_Mirrored", "Hole_Left_2_Mirrored"],
  baseName: "Hole_Right_"
})

// 5. Save
powerinspect_save_document({
  path: "C:\\Inspections\\SymmetricPart.pwi"
})
```

---

## Batch Tolerance Application

Apply different tolerance classes to groups of features.

```typescript
// 1. Connect and create features
powerinspect_connect()

// ... create various features ...

// 2. Define tolerance classes
const criticalTolerance = {
  name: "Critical",
  upperTolerance: 0.010,
  lowerTolerance: -0.010,
  description: "Critical fit surfaces"
}

const normalTolerance = {
  name: "Normal",
  upperTolerance: 0.025,
  lowerTolerance: -0.025,
  description: "Normal machining tolerance"
}

const coarseTolerance = {
  name: "Coarse",
  upperTolerance: 0.050,
  lowerTolerance: -0.050,
  description: "Coarse clearance holes"
}

// 3. Apply to critical features (bearing surfaces, mating faces)
powerinspect_apply_tolerances({
  featureNames: ["BearingJournal", "SealSurface", "MatingShoulder"],
  toleranceClass: criticalTolerance
})

// 4. Apply to normal features (standard holes, surfaces)
powerinspect_apply_tolerances({
  featureNames: ["Hole1", "Hole2", "Hole3", "Face1", "Face2"],
  toleranceClass: normalTolerance
})

// 5. Apply to coarse features (clearance holes, rough surfaces)
powerinspect_apply_tolerances({
  featureNames: ["ClearanceHole1", "ClearanceHole2", "RoughSurface"],
  toleranceClass: coarseTolerance
})

// 6. Configure report to show only critical features in summary
powerinspect_set_report_output({
  featureNames: ["Hole1", "Hole2", "Hole3", "ClearanceHole1", "ClearanceHole2"],
  outputToReport: false
})

powerinspect_set_report_output({
  featureNames: ["BearingJournal", "SealSurface", "MatingShoulder"],
  outputToReport: true,
  properties: ["diameter", "X", "Y", "Z", "circularity"]
})

// 7. Save
powerinspect_save_document({
  path: "C:\\Inspections\\Grouped Tolerances.pwi"
})
```

---

## ERP Integration Workflow

Integrate with ERPNext to pull work order specifications and create inspection programs.

```typescript
// This example shows how you might combine PowerInspect MCP with your ERPNext MCP

// 1. Get work order from ERPNext (using your cnc-erpnext MCP)
// erpnext_get_work_order({ name: "WO-2024-001" })
// Returns: part number, drawing specs, tolerances, qty

// 2. Connect to PowerInspect
powerinspect_connect()

// 3. Create inspection program based on drawing specs
// (This would be parsed from the ERPNext data)
const partSpecs = {
  holes: [
    { name: "Hole1", x: 25, y: 25, z: 0, diameter: 10.0, tolerance: 0.02 },
    { name: "Hole2", x: 75, y: 25, z: 0, diameter: 10.0, tolerance: 0.02 },
    { name: "Hole3", x: 25, y: 75, z: 0, diameter: 10.0, tolerance: 0.02 },
    { name: "Hole4", x: 75, y: 75, z: 0, diameter: 10.0, tolerance: 0.02 }
  ]
}

// 4. Generate features from specs
for (const hole of partSpecs.holes) {
  powerinspect_create_circle({
    name: hole.name,
    center: { x: hole.x, y: hole.y, z: hole.z },
    diameter: hole.diameter,
    upperTolerance: hole.tolerance,
    lowerTolerance: -hole.tolerance,
    outputToReport: true
  })
}

// 5. Configure probe paths
const holeNames = partSpecs.holes.map(h => h.name)
powerinspect_refresh_probe_paths({
  featureNames: holeNames
})

// 6. Validate
powerinspect_validate_program({
  checkTolerances: true,
  checkClearances: true
})

// 7. Save with work order reference
powerinspect_save_document({
  path: `C:\\Inspections\\WO-2024-001_${Date.now()}.pwi`
})

// 8. After inspection, export results
powerinspect_export_to_spc({
  format: "QDAS",
  outputPath: "C:\\Exports\\WO-2024-001_Results.q2d"
})

// 9. Post results back to ERPNext quality module
// erpnext_create_quality_inspection({
//   work_order: "WO-2024-001",
//   status: "Accepted",
//   inspection_file: "C:\\Exports\\WO-2024-001_Results.q2d"
// })
```

---

## Advanced Transformations

Complex transformation sequences for creating patterns.

```typescript
// 1. Connect
powerinspect_connect()

// 2. Create base feature
powerinspect_create_circle({
  name: "BaseHole",
  center: { x: 50, y: 0, z: 0 },
  diameter: 10.0,
  upperTolerance: 0.02,
  lowerTolerance: -0.02,
  outputToReport: true
})

// 3. Create circular array by rotation
for (let i = 1; i < 8; i++) {
  const angle = i * 45  // 8 features at 45° intervals
  
  // Rotate base feature
  powerinspect_transform_features({
    featureNames: ["BaseHole"],
    transformation: {
      type: "rotate",
      axis: "Z",
      angle: angle
    }
  })
}

// 4. Rename rotated features
const rotatedNames = ["BaseHole_45", "BaseHole_90", "BaseHole_135", "BaseHole_180", 
                      "BaseHole_225", "BaseHole_270", "BaseHole_315"]
powerinspect_rename_sequential({
  featureNames: rotatedNames,
  baseName: "RadialHole_"
})

// 5. Create another set offset in Z
powerinspect_transform_features({
  featureNames: ["BaseHole", ...rotatedNames],
  transformation: {
    type: "translate",
    x: 0,
    y: 0,
    z: 25.0
  }
})

// 6. Save
powerinspect_save_document({
  path: "C:\\Inspections\\ComplexPattern.pwi"
})
```

---

## Tips and Best Practices

### 1. Always Start with Datums
Establish primary datum features (planes, cylinders) before creating measured features.

### 2. Use Descriptive Names
Name features clearly: "Hole_TopLeft_M8" is better than "H1".

### 3. Configure Probe Paths Early
Set safe distances and approach angles right after creating features to catch clearance issues early.

### 4. Batch Operations Save Time
Use batch operations for applying tolerances, refreshing probe paths, and configuring reports.

### 5. Validate Before Running
Always call `powerinspect_validate_program` before generating CNC code or running inspection.

### 6. Use Pattern Tools
For repetitive features, use bolt circles, grids, and transformations instead of creating each feature individually.

### 7. Document with Comments
Add comments to critical features to help future users understand the inspection intent.

### 8. Export for SPC
Regularly export to QDAS or CSV format for statistical process control and trend analysis.

### 9. Integration with ERP
Link inspection programs to work orders for complete traceability from order to quality verification.

### 10. Template Reuse
Save completed programs as templates for similar parts to speed up future setup.

---

## Next Steps

1. Review the main README.md for installation and setup
2. Check DEVELOPMENT.md for implementing the COM API connection
3. Start with simple examples and build up to complex patterns
4. Integrate with your existing ERP and CAD workflows

For questions and support, see the main README.md file.
