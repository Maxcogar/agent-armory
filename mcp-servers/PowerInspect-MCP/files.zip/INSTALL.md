# PowerInspect MCP Server - Installation Guide

## Requirements

### System Requirements
- **OS**: Windows 10/11 (PowerInspect and COM automation require Windows)
- **PowerInspect**: Version 2017 (17.1.0) or later installed and licensed
- **Node.js**: Version 18 or later
- **Build Tools**: Visual Studio Build Tools (for compiling native modules)

### Why Windows Only?
PowerInspect uses Microsoft COM (Component Object Model) for automation, which is Windows-specific. The `winax` package provides Node.js bindings to COM but only works on Windows.

## Step-by-Step Installation

### 1. Install Visual Studio Build Tools

The `winax` package requires native compilation. Install Visual Studio Build Tools:

**Option A: Using winget (Windows 11/10)**
```powershell
winget install Microsoft.VisualStudio.2022.BuildTools
```

**Option B: Manual Download**
1. Download from: https://visualstudio.microsoft.com/downloads/
2. Select "Build Tools for Visual Studio 2022"
3. Install with "Desktop development with C++" workload

### 2. Install Node.js

Download and install Node.js 18+ from https://nodejs.org/

Verify installation:
```powershell
node --version
# Should show v18.x.x or higher
```

### 3. Clone/Download the MCP Server

```powershell
# If you have the files
cd path\to\powerinspect-mcp
```

### 4. Install Dependencies

```powershell
npm install
```

**What this does:**
- Installs MCP SDK for server functionality
- Installs `winax` and compiles native COM bindings (takes 1-2 minutes)
- Installs Zod for input validation
- Installs TypeScript compiler

**If `winax` fails to install:**

The most common issue is missing Visual Studio Build Tools. Make sure you have them installed with C++ support.

You can also try:
```powershell
npm install --global windows-build-tools
npm install
```

### 5. Build the TypeScript Code

```powershell
npm run build
```

This compiles TypeScript to JavaScript in the `dist/` folder.

### 6. Test the Installation

```powershell
# Test with MCP Inspector
npx @modelcontextprotocol/inspector dist/index.js
```

This opens a web interface where you can test tools interactively.

## Troubleshooting

### Error: "winax" module not found

**Solution**: Make sure `npm install` completed successfully. Check that `node_modules/winax` exists.

If not:
```powershell
npm install winax --save
```

### Error: "node-gyp" compilation failed

**Solution**: Install Visual Studio Build Tools:
```powershell
npm install --global windows-build-tools
npm install
```

### Error: "PowerINSPECT.Application" cannot be created

**Possible causes:**
1. PowerInspect not installed
2. PowerInspect not licensed
3. Running as non-administrator (try running PowerShell as Administrator)

**Solution**:
1. Verify PowerInspect is installed and opens normally
2. Check license is valid
3. Try running Node.js as Administrator

### Error: "No active document"

**Solution**: Open a document in PowerInspect before connecting via MCP. The MCP server works with the currently active document.

## Configuration

### For Use with Claude Desktop

Add to your Claude Desktop config file:

**Location**: `%APPDATA%\Claude\claude_desktop_config.json`

```json
{
  "mcpServers": {
    "powerinspect": {
      "command": "node",
      "args": ["C:\\path\\to\\powerinspect-mcp\\dist\\index.js"],
      "env": {}
    }
  }
}
```

Replace `C:\\path\\to\\powerinspect-mcp` with your actual installation path.

### For Use with Other MCP Clients

The server uses stdio transport and can be used with any MCP-compatible client. Provide the path to `dist/index.js` as the command.

## Verifying the Installation

### Test 1: Connect to PowerInspect

1. Open PowerInspect
2. Create or open an inspection program
3. Run MCP Inspector: `npx @modelcontextprotocol/inspector dist/index.js`
4. Call `powerinspect_connect` tool
5. Should return: `{ success: true, message: "Connected to PowerInspect X.Y" }`

### Test 2: Create a Feature

With PowerInspect connected:
1. Call `powerinspect_create_circle` with:
   ```json
   {
     "name": "TestHole",
     "center": { "x": 10, "y": 20, "z": 0 },
     "diameter": 12
   }
   ```
2. Check PowerInspect - you should see "TestHole" appear in the features list

### Test 3: Full Workflow

Run through the flange example in EXAMPLES.md to verify all functionality.

## Next Steps

- **Quick Start**: Read QUICKSTART.md for your first programs
- **Examples**: Check EXAMPLES.md for real-world workflows
- **Full Docs**: See README.md for complete tool reference

## Performance Notes

### First Connection
The first time you connect to PowerInspect after booting Windows, COM object creation can take 5-10 seconds. Subsequent connections are faster.

### Large Programs
Creating many features (50+) can be slow. Use batch operations and patterns (bolt circles, grids) instead of individual feature creation.

### Memory Usage
PowerInspect COM objects don't release immediately. If running long automation sessions, restart PowerInspect periodically to clear memory.

## Security Considerations

### Administrator Rights
Some COM automation may require administrator privileges. If you get "Access Denied" errors, try running as Administrator.

### Network Security
If exposing this server over network (not recommended for stdio transport), ensure proper firewall rules and authentication.

### File Paths
Always validate file paths before saving/opening documents. The MCP server has full file system access through PowerInspect.

## Uninstallation

To completely remove:

```powershell
# Remove Node modules
rm -r node_modules

# Remove build output
rm -r dist

# Remove the entire directory if desired
cd ..
rm -r powerinspect-mcp
```

To remove from Claude Desktop, delete the "powerinspect" entry from `claude_desktop_config.json`.

## Getting Help

- Check DEVELOPMENT.md for implementation details
- Review EXAMPLES.md for usage patterns
- Check PowerInspect API documentation
- Open an issue if you find bugs

---

**Successfully installed?** Head to QUICKSTART.md to create your first inspection program!
