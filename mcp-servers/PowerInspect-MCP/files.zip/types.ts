/**
 * PowerInspect MCP Server Types
 * Type definitions for Autodesk PowerInspect COM API
 */

// Feature Types
export enum FeatureType {
  // Probed Features
  PLANE_PROBED = 'Plane_Probed',
  LINE_PROBED = 'Line_Probed',
  POINT_RETRACE = 'Point_RetracePoint',
  CIRCLE_PROBED = 'Feat_ProbedCircle',
  CIRCLE_SINGLE_POINT = 'Feat_SinglePointCircle',
  ELLIPSE_PROBED = 'Feat_ProbedEllipse',
  SLOT = 'Feat_Slot',
  RECTANGLE = 'Feat_Rectangle',
  POLYGON = 'Feat_Polygone',
  CYLINDER = 'Feat_Cylinder',
  CONE = 'Feat_Cone',
  SPHERE = 'Feat_Sphere',
  TORUS = 'Feat_Torus',
  CIRCLE_THROUGH_N_POINTS = 'Feat_CircleThroughNPoints',
  
  // Compound Features
  COMPOUND_CIRCLE = 'Compound_Circle',
  COMPOUND_ELLIPSE = 'Compound_Ellipse',
  COMPOUND_RECTANGLE = 'Compound_Rectangle',
  COMPOUND_SLOT = 'Compound_Slot',
  COMPOUND_POLYGON = 'Compound_Polygon',
  COMPOUND_LINE = 'Compound_Line',
  
  // Surface Features
  SURFACE_POINT_GUIDED = 'ISurfacePointItem',
  SURFACE_GROUP = 'ISurfaceGroup'
}

// Coordinate Types
export enum CoordinateType {
  CARTESIAN = 'geomp3d_CARTESIAN',
  CYLINDRICAL = 'geomp3d_CYLINDRICAL',
  SPHERICAL = 'geomp3d_SPHERICAL'
}

// Radial Dimension Types
export enum RadialDimensionType {
  DIAMETER = 'pwi_Diameter',
  RADIUS = 'pwi_Radius'
}

// Fitting Algorithms
export enum FittingAlgorithm {
  LEAST_SQUARES = 'LEAST_SQUARES',
  MAX_INSCRIBED = 'MAX_INSCRIBED',
  MIN_CIRCUMSCRIBED = 'MIN_CIRCUMSCRIBED'
}

// Probe Compensation Methods
export enum CompensationMethod {
  ALONG_EXPLICIT_DIRECTION = 'ALONG_EXPLICIT_DIRECTION',
  NORMAL_TO_SURFACE = 'NORMAL_TO_SURFACE'
}

// Probe Compensation Vectors
export enum CompensationVector {
  X_PLUS = 'X+',
  X_MINUS = 'X-',
  Y_PLUS = 'Y+',
  Y_MINUS = 'Y-',
  Z_PLUS = 'Z+',
  Z_MINUS = 'Z-'
}

// Units
export enum Units {
  MILLIMETERS = 'units_MILLIMETERS',
  INCHES = 'units_INCHES'
}

// Export Formats
export enum ExportFormat {
  CSV = 'CSV',
  SDD = 'SDD',
  QDAS = 'QDAS',
  SCRIPT = 'SCRIPT'
}

// Point 3D
export interface Point3D {
  x: number;
  y: number;
  z: number;
}

// Vector 3D
export interface Vector3D {
  i: number;
  j: number;
  k: number;
}

// Feature Configuration
export interface FeatureConfig {
  name: string;
  featureType: FeatureType;
  position?: Point3D;
  useNominals?: boolean;
  outputToReport?: boolean;
  visible?: boolean;
  comment?: string;
}

// Circle Configuration
export interface CircleConfig extends FeatureConfig {
  center: Point3D;
  diameter?: number;
  radius?: number;
  radialDimensionType?: RadialDimensionType;
  upperTolerance?: number;
  lowerTolerance?: number;
  fittingAlgorithm?: FittingAlgorithm;
  normalVector?: Vector3D;
}

// Point Configuration
export interface PointConfig extends FeatureConfig {
  targetPoint: Point3D;
  compensationMethod?: CompensationMethod;
  compensationVector?: CompensationVector;
  outputX?: boolean;
  outputY?: boolean;
  outputZ?: boolean;
}

// Plane Configuration
export interface PlaneConfig extends FeatureConfig {
  basePoint: Point3D;
  normalVector: Vector3D;
  pointCount?: number;
}

// Cylinder Configuration
export interface CylinderConfig extends FeatureConfig {
  basePoint: Point3D;
  axisVector: Vector3D;
  diameter?: number;
  radius?: number;
  height?: number;
  radialDimensionType?: RadialDimensionType;
  upperTolerance?: number;
  lowerTolerance?: number;
}

// Probe Path Configuration
export interface ProbePathConfig {
  featureName: string;
  safeDistance?: number;
  approachAngle?: number;
  reverseDirection?: boolean;
}

// Pattern Configuration
export interface PatternConfig {
  baseFeatureName: string;
  patternType: 'linear' | 'circular' | 'grid';
  count?: number;
  spacing?: number;
  angle?: number;
  rows?: number;
  columns?: number;
}

// Bolt Circle Configuration
export interface BoltCircleConfig {
  name: string;
  centerX: number;
  centerY: number;
  centerZ: number;
  diameter: number;
  holeCount: number;
  holeDiameter: number;
  startAngle?: number;
  tolerance?: number;
}

// Transformation
export interface Transformation {
  type: 'translate' | 'rotate' | 'mirror' | 'scale';
  x?: number;
  y?: number;
  z?: number;
  axis?: 'X' | 'Y' | 'Z';
  angle?: number;
  factor?: number;
}

// Program Summary
export interface ProgramSummary {
  documentName: string;
  units: Units;
  featureCount: number;
  features: FeatureSummary[];
  saved: boolean;
}

// Feature Summary
export interface FeatureSummary {
  name: string;
  type: string;
  position?: Point3D;
  outputToReport: boolean;
}

// Validation Result
export interface ValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
}

// API Response
export interface APIResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

// Tolerance Class
export interface ToleranceClass {
  name: string;
  upperTolerance: number;
  lowerTolerance: number;
  description?: string;
}
