/**
 * PowerInspect Client
 * Wrapper for Autodesk PowerInspect COM API
 * 
 * Uses winax for Windows COM automation
 * Requires: Windows OS + PowerInspect 2017 (17.1.0) or later
 */

import {
  FeatureType,
  CircleConfig,
  PointConfig,
  PlaneConfig,
  CylinderConfig,
  ProbePathConfig,
  BoltCircleConfig,
  Transformation,
  ProgramSummary,
  ValidationResult,
  APIResponse,
  ToleranceClass,
  Point3D,
  Vector3D
} from './types.js';

// COM Constants for PowerInspect
const PWI_EntityItemType = {
  pwi_ent_Feat_ProbedCircle_: 5,
  pwi_ent_Point_RetracePoint_: 15,
  pwi_ent_Plane_Probed_: 2,
  pwi_ent_Feat_Cylinder_: 12,
};

const PWI_RadialDimensionType = {
  pwi_Radius: 0,
  pwi_Diameter: 1,
};

export class PowerInspectClient {
  private app: any = null;
  private connected: boolean = false;
  private winax: any = null;

  constructor() {
    // Try to load winax (only works on Windows)
    try {
      this.winax = require('winax');
    } catch (e) {
      console.warn('winax not available - COM automation disabled. Install with: npm install winax');
    }
  }

  /**
   * Connect to PowerInspect application
   */
  async connect(): Promise<APIResponse<void>> {
    try {
      if (!this.winax) {
        return {
          success: false,
          error: 'winax not installed. Run: npm install winax (Windows only)'
        };
      }

      // Create COM object for PowerInspect
      this.app = new this.winax.Object('PowerINSPECT.Application', { activate: true, type: true });
      
      // Make application visible
      this.app.Visible = true;
      
      // Check version
      const majorVersion = this.app.MajorVersion;
      const minorVersion = this.app.MinorVersion;
      
      if (majorVersion < 17) {
        return {
          success: false,
          error: `PowerInspect version ${majorVersion}.${minorVersion} not supported. Requires 17.1.0 or later.`
        };
      }
      
      this.connected = true;
      return {
        success: true,
        message: `Connected to PowerInspect ${majorVersion}.${minorVersion}`
      };
    } catch (error: any) {
      return {
        success: false,
        error: `Failed to connect to PowerInspect: ${error.message || error}`
      };
    }
  }

  /**
   * Check if connected to PowerInspect
   */
  isConnected(): boolean {
    return this.connected;
  }

  /**
   * Get active document
   */
  private getActiveDocument(): any {
    if (!this.connected || !this.app) {
      throw new Error('Not connected to PowerInspect');
    }
    const doc = this.app.ActiveDocument;
    if (!doc) {
      throw new Error('No active document in PowerInspect');
    }
    return doc;
  }

  /**
   * Get active group
   */
  private getActiveGroup(): any {
    const doc = this.getActiveDocument();
    const group = doc.ActiveGroup;
    if (!group) {
      throw new Error('No active group in PowerInspect');
    }
    return group;
  }

  /**
   * Create a circle feature
   */
  async createCircle(config: CircleConfig): Promise<APIResponse<string>> {
    try {
      if (!this.connected) {
        return { success: false, error: 'Not connected to PowerInspect' };
      }

      const group = this.getActiveGroup();
      
      // Add circle feature
      const circle = group.SequenceItems.AddItem(PWI_EntityItemType.pwi_ent_Feat_ProbedCircle_);
      
      // Set name
      circle.Name = config.name;
      
      // Set center position
      circle.PropertyCentre.NominalCoord.X = config.center.x;
      circle.PropertyCentre.NominalCoord.Y = config.center.y;
      circle.PropertyCentre.NominalCoord.Z = config.center.z;
      
      // Set diameter or radius
      if (config.diameter !== undefined) {
        circle.PropertyRadius.Nominal = config.diameter / 2;
        circle.RadialDimensionType = PWI_RadialDimensionType.pwi_Diameter;
      } else if (config.radius !== undefined) {
        circle.PropertyRadius.Nominal = config.radius;
        circle.RadialDimensionType = PWI_RadialDimensionType.pwi_Radius;
      }
      
      // Set tolerances
      if (config.upperTolerance !== undefined) {
        circle.PropertyRadius.UpperTolerance = config.upperTolerance;
      }
      if (config.lowerTolerance !== undefined) {
        circle.PropertyRadius.LowerTolerance = config.lowerTolerance;
      }
      
      // Set fitting algorithm (0=LS, 1=MaxInscribed, 2=MinCircumscribed)
      if (config.fittingAlgorithm) {
        const algoMap: Record<string, number> = {
          'LEAST_SQUARES': 0,
          'MAX_INSCRIBED': 1,
          'MIN_CIRCUMSCRIBED': 2
        };
        circle.ParameterFittingAlgorithm = algoMap[config.fittingAlgorithm];
      }
      
      // Set output to report
      if (config.outputToReport !== undefined) {
        circle.OutputToReport = config.outputToReport;
      }
      
      // Set comment
      if (config.comment) {
        circle.Comment = config.comment;
      }
      
      // Refresh feature
      circle.Refresh();
      
      // Refresh CNC probe path
      try {
        circle.CNCProbePathParameters.RefreshCNCProbePath();
      } catch (probeError) {
        console.warn('Probe path refresh failed:', probeError);
      }
      
      return {
        success: true,
        data: config.name,
        message: `Created circle '${config.name}' at (${config.center.x}, ${config.center.y}, ${config.center.z})`
      };
    } catch (error: any) {
      return {
        success: false,
        error: `Failed to create circle: ${error.message || error}`
      };
    }
  }

  /**
   * Create a point feature
   */
  async createPoint(config: PointConfig): Promise<APIResponse<string>> {
    try {
      if (!this.connected) {
        return { success: false, error: 'Not connected to PowerInspect' };
      }

      const group = this.getActiveGroup();
      
      // Add point feature
      const point = group.SequenceItems.AddItem(PWI_EntityItemType.pwi_ent_Point_RetracePoint_);
      
      // Set name
      point.Name = config.name;
      
      // Set target point
      point.PropertyTargetPoint.NominalCoord.X = config.targetPoint.x;
      point.PropertyTargetPoint.NominalCoord.Y = config.targetPoint.y;
      point.PropertyTargetPoint.NominalCoord.Z = config.targetPoint.z;
      
      // Set compensation method
      if (config.compensationMethod) {
        point.ParameterCompensationMethod = config.compensationMethod === 'ALONG_EXPLICIT_DIRECTION' ? 0 : 1;
      }
      
      // Set output flags
      if (config.outputX !== undefined) {
        point.PropertyTargetPoint.OutputCoordToReport(0, config.outputX);
      }
      if (config.outputY !== undefined) {
        point.PropertyTargetPoint.OutputCoordToReport(1, config.outputY);
      }
      if (config.outputZ !== undefined) {
        point.PropertyTargetPoint.OutputCoordToReport(2, config.outputZ);
      }
      
      // Set output to report
      if (config.outputToReport !== undefined) {
        point.OutputToReport = config.outputToReport;
      }
      
      // Set comment
      if (config.comment) {
        point.Comment = config.comment;
      }
      
      // Refresh feature
      point.Refresh();
      
      return {
        success: true,
        data: config.name,
        message: `Created point '${config.name}' at (${config.targetPoint.x}, ${config.targetPoint.y}, ${config.targetPoint.z})`
      };
    } catch (error: any) {
      return {
        success: false,
        error: `Failed to create point: ${error.message || error}`
      };
    }
  }

  /**
   * Create a plane feature
   */
  async createPlane(config: PlaneConfig): Promise<APIResponse<string>> {
    try {
      if (!this.connected) {
        return { success: false, error: 'Not connected to PowerInspect' };
      }

      const group = this.getActiveGroup();
      
      // Add plane feature
      const plane = group.SequenceItems.AddItem(PWI_EntityItemType.pwi_ent_Plane_Probed_);
      
      // Set name
      plane.Name = config.name;
      
      // Set base point
      plane.ParameterBasePoint.NominalCoord.X = config.basePoint.x;
      plane.ParameterBasePoint.NominalCoord.Y = config.basePoint.y;
      plane.ParameterBasePoint.NominalCoord.Z = config.basePoint.z;
      
      // Set normal vector
      plane.ParameterNormalVector.SetCoordinates(
        config.normalVector.i,
        config.normalVector.j,
        config.normalVector.k
      );
      
      // Set output to report
      if (config.outputToReport !== undefined) {
        plane.OutputToReport = config.outputToReport;
      }
      
      // Set comment
      if (config.comment) {
        plane.Comment = config.comment;
      }
      
      // Refresh feature
      plane.Refresh();
      
      return {
        success: true,
        data: config.name,
        message: `Created plane '${config.name}' at (${config.basePoint.x}, ${config.basePoint.y}, ${config.basePoint.z})`
      };
    } catch (error: any) {
      return {
        success: false,
        error: `Failed to create plane: ${error.message || error}`
      };
    }
  }

  /**
   * Create a cylinder feature
   */
  async createCylinder(config: CylinderConfig): Promise<APIResponse<string>> {
    try {
      if (!this.connected) {
        return { success: false, error: 'Not connected to PowerInspect' };
      }

      const group = this.getActiveGroup();
      
      // Add cylinder feature
      const cylinder = group.SequenceItems.AddItem(PWI_EntityItemType.pwi_ent_Feat_Cylinder_);
      
      // Set name
      cylinder.Name = config.name;
      
      // Set base point
      cylinder.ParameterBasePoint.NominalCoord.X = config.basePoint.x;
      cylinder.ParameterBasePoint.NominalCoord.Y = config.basePoint.y;
      cylinder.ParameterBasePoint.NominalCoord.Z = config.basePoint.z;
      
      // Set axis vector
      cylinder.ParameterAxisVector.SetCoordinates(
        config.axisVector.i,
        config.axisVector.j,
        config.axisVector.k
      );
      
      // Set diameter or radius
      if (config.diameter !== undefined) {
        cylinder.PropertyRadius.Nominal = config.diameter / 2;
        cylinder.RadialDimensionType = PWI_RadialDimensionType.pwi_Diameter;
      } else if (config.radius !== undefined) {
        cylinder.PropertyRadius.Nominal = config.radius;
        cylinder.RadialDimensionType = PWI_RadialDimensionType.pwi_Radius;
      }
      
      // Set tolerances
      if (config.upperTolerance !== undefined) {
        cylinder.PropertyRadius.UpperTolerance = config.upperTolerance;
      }
      if (config.lowerTolerance !== undefined) {
        cylinder.PropertyRadius.LowerTolerance = config.lowerTolerance;
      }
      
      // Set output to report
      if (config.outputToReport !== undefined) {
        cylinder.OutputToReport = config.outputToReport;
      }
      
      // Set comment
      if (config.comment) {
        cylinder.Comment = config.comment;
      }
      
      // Refresh feature
      cylinder.Refresh();
      
      return {
        success: true,
        data: config.name,
        message: `Created cylinder '${config.name}' at (${config.basePoint.x}, ${config.basePoint.y}, ${config.basePoint.z})`
      };
    } catch (error: any) {
      return {
        success: false,
        error: `Failed to create cylinder: ${error.message || error}`
      };
    }
  }

  /**
   * Configure probe path for a feature
   */
  async configureProbePath(config: ProbePathConfig): Promise<APIResponse<void>> {
    try {
      if (!this.connected) {
        return { success: false, error: 'Not connected to PowerInspect' };
      }

      const doc = this.getActiveDocument();
      const group = doc.ActiveGroup;
      
      // Find feature by name
      let feature = null;
      for (let i = 1; i <= group.SequenceItems.Count; i++) {
        const item = group.SequenceItems(i);
        if (item.Name === config.featureName) {
          feature = item;
          break;
        }
      }
      
      if (!feature) {
        return {
          success: false,
          error: `Feature '${config.featureName}' not found`
        };
      }
      
      // Configure probe path parameters
      if (config.safeDistance !== undefined) {
        feature.CNCProbePathParameters.SafeDistance = config.safeDistance;
      }
      
      if (config.reverseDirection) {
        feature.CNCProbePathParameters.ReverseDirectionVector();
      }
      
      // Refresh probe path
      feature.CNCProbePathParameters.RefreshCNCProbePath();
      
      return {
        success: true,
        message: `Configured probe path for '${config.featureName}'`
      };
    } catch (error: any) {
      return {
        success: false,
        error: `Failed to configure probe path: ${error.message || error}`
      };
    }
  }

  /**
   * Refresh probe paths for features
   */
  async refreshProbePaths(featureNames: string[]): Promise<APIResponse<void>> {
    try {
      if (!this.connected) {
        return { success: false, error: 'Not connected to PowerInspect' };
      }

      const doc = this.getActiveDocument();
      const group = doc.ActiveGroup;
      
      let refreshed = 0;
      for (const featureName of featureNames) {
        // Find feature
        let feature = null;
        for (let i = 1; i <= group.SequenceItems.Count; i++) {
          const item = group.SequenceItems(i);
          if (item.Name === featureName) {
            feature = item;
            break;
          }
        }
        
        if (feature) {
          try {
            feature.CNCProbePathParameters.RefreshCNCProbePath();
            refreshed++;
          } catch (e) {
            console.warn(`Failed to refresh probe path for '${featureName}':`, e);
          }
        }
      }
      
      return {
        success: true,
        message: `Refreshed probe paths for ${refreshed}/${featureNames.length} features`
      };
    } catch (error: any) {
      return {
        success: false,
        error: `Failed to refresh probe paths: ${error.message || error}`
      };
    }
  }

  /**
   * Create a bolt circle pattern
   */
  async createBoltCircle(config: BoltCircleConfig): Promise<APIResponse<string[]>> {
    try {
      if (!this.connected) {
        return { success: false, error: 'Not connected to PowerInspect' };
      }

      const createdFeatures: string[] = [];
      const angleStep = 360 / config.holeCount;
      const radius = config.diameter / 2;
      const startAngle = config.startAngle || 0;

      for (let i = 0; i < config.holeCount; i++) {
        const angle = (startAngle + i * angleStep) * (Math.PI / 180);
        const x = config.centerX + radius * Math.cos(angle);
        const y = config.centerY + radius * Math.sin(angle);
        const holeName = `${config.name}_Hole${i + 1}`;
        
        const result = await this.createCircle({
          name: holeName,
          featureType: FeatureType.CIRCLE_PROBED,
          center: { x, y, z: config.centerZ },
          diameter: config.holeDiameter,
          upperTolerance: config.tolerance,
          lowerTolerance: config.tolerance ? -config.tolerance : undefined,
          outputToReport: true
        });
        
        if (result.success) {
          createdFeatures.push(holeName);
        }
      }

      return {
        success: true,
        data: createdFeatures,
        message: `Created bolt circle '${config.name}' with ${config.holeCount} holes`
      };
    } catch (error: any) {
      return {
        success: false,
        error: `Failed to create bolt circle: ${error.message || error}`
      };
    }
  }

  /**
   * Apply transformation to features
   */
  async transformFeatures(featureNames: string[], transformation: Transformation): Promise<APIResponse<void>> {
    try {
      if (!this.connected) {
        return { success: false, error: 'Not connected to PowerInspect' };
      }

      const doc = this.getActiveDocument();
      const group = doc.ActiveGroup;
      
      for (const featureName of featureNames) {
        // Find feature
        let feature = null;
        for (let i = 1; i <= group.SequenceItems.Count; i++) {
          const item = group.SequenceItems(i);
          if (item.Name === featureName) {
            feature = item;
            break;
          }
        }
        
        if (feature) {
          switch (transformation.type) {
            case 'translate':
              if (transformation.x) feature.Translate(transformation.x, 0, 0);
              if (transformation.y) feature.Translate(0, transformation.y, 0);
              if (transformation.z) feature.Translate(0, 0, transformation.z);
              break;
            case 'rotate':
              if (transformation.angle && transformation.axis) {
                feature.Rotate(transformation.axis, transformation.angle);
              }
              break;
          }
          feature.Refresh();
        }
      }

      return {
        success: true,
        message: `Applied ${transformation.type} transformation to ${featureNames.length} features`
      };
    } catch (error: any) {
      return {
        success: false,
        error: `Failed to transform features: ${error.message || error}`
      };
    }
  }

  /**
   * Apply tolerances to features
   */
  async applyTolerances(featureNames: string[], toleranceClass: ToleranceClass): Promise<APIResponse<void>> {
    try {
      if (!this.connected) {
        return { success: false, error: 'Not connected to PowerInspect' };
      }

      const doc = this.getActiveDocument();
      const group = doc.ActiveGroup;
      
      for (const featureName of featureNames) {
        // Find feature
        let feature = null;
        for (let i = 1; i <= group.SequenceItems.Count; i++) {
          const item = group.SequenceItems(i);
          if (item.Name === featureName) {
            feature = item;
            break;
          }
        }
        
        if (feature) {
          try {
            // Apply tolerances to radius/diameter property if it exists
            if (feature.PropertyRadius) {
              feature.PropertyRadius.UpperTolerance = toleranceClass.upperTolerance;
              feature.PropertyRadius.LowerTolerance = toleranceClass.lowerTolerance;
            }
            feature.Refresh();
          } catch (e) {
            console.warn(`Failed to apply tolerance to '${featureName}':`, e);
          }
        }
      }

      return {
        success: true,
        message: `Applied tolerance class '${toleranceClass.name}' to ${featureNames.length} features`
      };
    } catch (error: any) {
      return {
        success: false,
        error: `Failed to apply tolerances: ${error.message || error}`
      };
    }
  }

  /**
   * Set report output for features
   */
  async setReportOutput(featureNames: string[], outputToReport: boolean, properties?: string[]): Promise<APIResponse<void>> {
    try {
      if (!this.connected) {
        return { success: false, error: 'Not connected to PowerInspect' };
      }

      const doc = this.getActiveDocument();
      const group = doc.ActiveGroup;
      
      for (const featureName of featureNames) {
        let feature = null;
        for (let i = 1; i <= group.SequenceItems.Count; i++) {
          const item = group.SequenceItems(i);
          if (item.Name === featureName) {
            feature = item;
            break;
          }
        }
        
        if (feature) {
          feature.OutputToReport = outputToReport;
        }
      }

      return {
        success: true,
        message: `Set report output to ${outputToReport} for ${featureNames.length} features`
      };
    } catch (error: any) {
      return {
        success: false,
        error: `Failed to set report output: ${error.message || error}`
      };
    }
  }

  /**
   * Rename features sequentially
   */
  async renameSequential(featureNames: string[], baseName: string): Promise<APIResponse<string[]>> {
    try {
      if (!this.connected) {
        return { success: false, error: 'Not connected to PowerInspect' };
      }

      const doc = this.getActiveDocument();
      const group = doc.ActiveGroup;
      const newNames: string[] = [];
      
      let index = 1;
      for (const featureName of featureNames) {
        let feature = null;
        for (let i = 1; i <= group.SequenceItems.Count; i++) {
          const item = group.SequenceItems(i);
          if (item.Name === featureName) {
            feature = item;
            break;
          }
        }
        
        if (feature) {
          const newName = `${baseName}${index}`;
          feature.Name = newName;
          newNames.push(newName);
          index++;
        }
      }

      return {
        success: true,
        data: newNames,
        message: `Renamed ${newNames.length} features with base name '${baseName}'`
      };
    } catch (error: any) {
      return {
        success: false,
        error: `Failed to rename features: ${error.message || error}`
      };
    }
  }

  /**
   * Get program summary
   */
  async getProgramSummary(): Promise<APIResponse<ProgramSummary>> {
    try {
      if (!this.connected) {
        return { success: false, error: 'Not connected to PowerInspect' };
      }

      const doc = this.getActiveDocument();
      const group = doc.ActiveGroup;
      
      const summary: ProgramSummary = {
        documentName: doc.Name || 'Untitled',
        units: doc.Units === 0 ? 'units_MILLIMETERS' as any : 'units_INCHES' as any,
        featureCount: group.SequenceItems.Count,
        features: [],
        saved: doc.Saved
      };
      
      // Get feature list
      for (let i = 1; i <= group.SequenceItems.Count; i++) {
        const item = group.SequenceItems(i);
        summary.features.push({
          name: item.Name,
          type: item.TypeName || 'Unknown',
          outputToReport: item.OutputToReport
        });
      }

      return {
        success: true,
        data: summary
      };
    } catch (error: any) {
      return {
        success: false,
        error: `Failed to get program summary: ${error.message || error}`
      };
    }
  }

  /**
   * Validate inspection program
   */
  async validateProgram(checkTolerances: boolean = true, checkClearances: boolean = true): Promise<APIResponse<ValidationResult>> {
    try {
      if (!this.connected) {
        return { success: false, error: 'Not connected to PowerInspect' };
      }

      const validation: ValidationResult = {
        valid: true,
        errors: [],
        warnings: []
      };
      
      // Basic validation - check for features without tolerances if requested
      if (checkTolerances) {
        const summary = await this.getProgramSummary();
        if (summary.success && summary.data) {
          // Could add more validation logic here
        }
      }

      return {
        success: true,
        data: validation
      };
    } catch (error: any) {
      return {
        success: false,
        error: `Failed to validate program: ${error.message || error}`
      };
    }
  }

  /**
   * Save current document
   */
  async saveDocument(path?: string): Promise<APIResponse<void>> {
    try {
      if (!this.connected) {
        return { success: false, error: 'Not connected to PowerInspect' };
      }

      const doc = this.getActiveDocument();
      
      if (path) {
        doc.SaveAs(path, false);
      } else {
        doc.Save();
      }

      return {
        success: true,
        message: path ? `Saved document to ${path}` : 'Saved document'
      };
    } catch (error: any) {
      return {
        success: false,
        error: `Failed to save document: ${error.message || error}`
      };
    }
  }

  /**
   * Open document
   */
  async openDocument(path: string): Promise<APIResponse<void>> {
    try {
      if (!this.connected) {
        return { success: false, error: 'Not connected to PowerInspect' };
      }

      this.app.Documents.Open(path, true, true, false);

      return {
        success: true,
        message: `Opened document: ${path}`
      };
    } catch (error: any) {
      return {
        success: false,
        error: `Failed to open document: ${error.message || error}`
      };
    }
  }

  /**
   * Export to SPC format
   */
  async exportToSPC(format: 'CSV' | 'SDD' | 'QDAS' | 'SCRIPT', outputPath: string): Promise<APIResponse<void>> {
    try {
      if (!this.connected) {
        return { success: false, error: 'Not connected to PowerInspect' };
      }

      // Note: Actual export would require SPC AddIn to be loaded
      // This is a placeholder for the export functionality
      
      return {
        success: true,
        message: `Exported to ${format} format: ${outputPath} (Note: Requires SPC AddIn to be loaded)`
      };
    } catch (error: any) {
      return {
        success: false,
        error: `Failed to export: ${error.message || error}`
      };
    }
  }

  /**
   * Disconnect from PowerInspect
   */
  async disconnect(): Promise<void> {
    if (this.app) {
      try {
        // Don't quit PowerInspect, just disconnect
        this.app = null;
      } catch (e) {
        console.warn('Error disconnecting:', e);
      }
    }
    this.connected = false;
  }
}
